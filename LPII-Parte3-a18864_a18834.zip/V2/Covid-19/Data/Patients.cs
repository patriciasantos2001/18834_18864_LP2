﻿using BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace DataAccess
{
    public class Patients : Persons
    {
        private static List<PatientBO> patient;
        private static string fileName;

        static Patients()
        {
            patient = new List<PatientBO>();
            fileName = @"Patients.bin";
        }

        #region OVERRIDE

        #endregion

        #region METHODS

        /// <summary>
        /// Show patients list
        /// </summary>
        /// <returns></returns>
        public static List<PatientBO> ShowPatient()
        {
            return patient;
        }

        /// <summary>
        /// Add patient
        /// </summary>
        /// <param name="pt"></param>
        /// <returns></returns>
        public static bool AddPatient(PatientBO pt)
        {
            if (patient.Contains(pt)) return false;
            patient.Add(pt);
            return true;
        }
        /// <summary>
        /// Update patient
        /// </summary>
        /// <param name="index"></param>
        /// <param name="pt"></param>
        /// <returns></returns>
        public static bool UpdatePatient(int index, PatientBO pt)
        {
            patient.Insert(index, pt);
            return true;
        }
        /// <summary>
        /// Save patients file
        /// </summary>
        public static void SaveFilePatients()
        {
            if (File.Exists(fileName))
            {
                FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.ReadWrite);
                BinaryFormatter bfw = new BinaryFormatter();
                bfw.Serialize(fs, patient);
                fs.Close();
            }
            else
            {
                FileStream fs = new FileStream(fileName, FileMode.Create, FileAccess.ReadWrite);
                BinaryFormatter bfw = new BinaryFormatter();
                bfw.Serialize(fs, patient);
                fs.Close();
            }
        }
        /// <summary>
        /// Load patients file
        /// </summary>
        public static void LoadFilePatients()
        {
            if (File.Exists(fileName))
            {
                Stream s = File.Open(fileName, FileMode.Open, FileAccess.Read);
                BinaryFormatter b = new BinaryFormatter();
                patient = (List<PatientBO>)b.Deserialize(s);
                s.Close();
            }
        }
        #endregion
    }
}