﻿using System;
using BusinessObjects;
using System.Collections.Generic;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace DataAccess
{
    public class Doctors
    {
        private static List<DoctorBO> doctor;
        private static string fileName;

        static Doctors()
        {
            doctor = new List<DoctorBO>();
            fileName = @"Doctors.bin";
        }

        /// <summary>
        /// Show doctors list
        /// </summary>
        /// <returns></returns>
        public static List<DoctorBO> ShowDoctor()
        {
            return doctor;
        }

        #region METHODS

        /// <summary>
        /// Add doctor
        /// </summary>
        /// <param name="d"></param>
        /// <returns></returns>
        public static bool AddDoctor(DoctorBO d)
        {
            if (doctor.Contains(d)) return false;
            doctor.Add(d);
            return true;
        }
        /// <summary>
        /// Update doctor
        /// </summary>
        /// <param name="index"></param>
        /// <param name="d"></param>
        /// <returns></returns>
        public static bool UpdateDoctor(int index, DoctorBO d)
        {
            doctor.Insert(index, d);
            return true;
        }
        /// <summary>
        /// Save doctor file
        /// </summary>
        public static void SaveFileDoctor()
        {
            FileStream fs = new FileStream(fileName, FileMode.Append, FileAccess.Write);
            BinaryFormatter bfw = new BinaryFormatter();
            bfw.Serialize(fs, doctor);
            fs.Close();
        }
        /// <summary>
        /// Load doctor file
        /// </summary>
        public static void LoadFileDoctor()
        {
            if (File.Exists(fileName))
            {
                Stream s = File.Open(fileName, FileMode.Open, FileAccess.Read);
                if (s.Length > 0)
                {
                    BinaryFormatter b = new BinaryFormatter();
                    doctor = (List<DoctorBO>)b.Deserialize(s);
                }
                s.Close();
            }
        }
        /// <summary>
        /// Verifies if the doctor exists
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        public static bool ExistDoctor(int code)
        {
            return doctor.Exists(d => d.CodeDoctor == code);
        }
        #endregion

    }
}
