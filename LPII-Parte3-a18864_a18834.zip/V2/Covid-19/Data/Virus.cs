﻿using System;
using System.Collections.Generic;
using System.Linq;
using BusinessObjects;
using System.Text;
using System.Threading.Tasks;

namespace Data
{
    public class Virus
    {
        private static List<VirusBO> virus;

        /// <summary>
        /// Show virus list
        /// </summary>
        static Virus()
        {
            virus = new List<VirusBO>();
        }

        #region OVERRIDE

        #endregion

        #region METHODS

        /// <summary>
        /// Insert data virus
        /// </summary>
        /// <param name="v"></param>
        /// <returns></returns>
        public static bool AddVirus(VirusBO v)
        {
            if (virus.Contains(v)) return false;
            virus.Add(v);
            return true;
        }
        /// <summary>
        /// Update virus data
        /// </summary>
        /// <param name="index"></param>
        /// <param name="v"></param>
        /// <returns></returns>
        public static bool UpdateVirus(int index, VirusBO v)
        {
            virus.Insert(index, v);
            return true;
        }
        #endregion
    }
}
