﻿using System;
using DataAccess;
using BusinessObjects;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessRules
{
    public class PersonBR
    {
        public PersonBR()
        {

        }
        /// <summary>
        /// Insertion of persons class attributes in the patient list
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        public static bool InsertPerson(PersonBO p)
        {
            return Persons.AddPerson(p);
        }
        /// <summary>
        /// Update of the persons class attributes in the patient list
        /// </summary>
        /// <param name="index"></param>
        /// <param name="p"></param>
        /// <returns></returns>
        public static bool UpdatePerson(int index, PersonBO p)
        {
            return Persons.UpdatePerson(index, p);
        }

    }
}
