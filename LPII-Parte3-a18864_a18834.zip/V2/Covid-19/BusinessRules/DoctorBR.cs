﻿using System;
using DataAccess;
using BusinessObjects;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessRules
{
    public class DoctorBR
    {
        public DoctorBR()
        {
        }
        /// <summary>
        /// Show Doctors List
        /// </summary>
        /// <returns></returns>
        public static List<DoctorBO> ShowDoctor()
        {
            return Doctors.ShowDoctor();
        }
        /// <summary>
        /// Insertion of doctors class attributes in the doctors list
        /// </summary>
        /// <param name="d"></param>
        /// <returns></returns>
        public static bool InsertDoctor(DoctorBO d)
        {
            return Doctors.AddDoctor(d);
        }
        /// <summary>
        /// Update of the doctors class attributes in the doctors list
        /// </summary>
        /// <param name="index"></param>
        /// <param name="d"></param>
        /// <returns></returns>
        public static bool UpdateDoctor(int index, DoctorBO d)
        {
            return Doctors.UpdateDoctor(index, d);
        }

        ///<summary>
        ///Save the list of doctors in the binary files 
        /// </summary>
        public static void SaveDoctorFile()
        {
            Doctors.SaveFileDoctor();
        }

        ///<summary>
        ///Load the list of patients from the binary files 
        /// </summary>
        public static void LoadDoctorFile()
        {
            Doctors.LoadFileDoctor();
        }
        /// <summary>
        /// Verifies if the doctor exists
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        public static bool ExistDoctor(int code)
        {
            return Doctors.ExistDoctor(code);
        }
    }
}
