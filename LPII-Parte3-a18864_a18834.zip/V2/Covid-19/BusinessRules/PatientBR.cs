﻿using System;
using DataAccess;
using BusinessObjects;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessRules
{
    public class PatientBR
    {
        public PatientBR()
        {
        }
        /// <summary>
        /// Show Patients
        /// </summary>
        /// <returns></returns>
        public static List<PatientBO> ShowPatients()
        {
            return Patients.ShowPatient();
        }
        /// <summary>
        /// Insertion of patients class attributes in the patient list
        /// </summary>
        /// <param name="pt"></param>
        /// <returns></returns>
        public static bool InsertPatient(PatientBO pt)
        {
            return Patients.AddPatient(pt); 
        }
        /// <summary>
        /// Update of the patients class attributes in the patient list
        /// </summary>
        /// <param name="index"></param>
        /// <param name="pt"></param>
        /// <returns></returns>
        public static bool UpdatePatient(int index, PatientBO pt)
        {
            return Patients.UpdatePatient(index, pt);
        }

        ///<summary>
        ///Save the list of patients in the binary files 
        /// </summary>
        public static void SavePatientFile()
        {
            Patients.SaveFilePatients();
        }

        ///<summary>
        ///Load the list of patients from the binary files 
        /// </summary>
        public static void LoadPatientFile()
        {
            Patients.LoadFilePatients();
        }
    }
}
