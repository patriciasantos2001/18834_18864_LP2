﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using BusinessObjects;
using Data;

namespace BusinessRules
{
    public class VirusBR
    {
        public VirusBR()
        {
        }
        /// <summary>
        /// Insertion of virus class attributes in the patient list
        /// </summary>
        /// <param name="v"></param>
        /// <returns></returns>
        public static bool InsertPerson(VirusBO v)
        {
            return Virus.AddVirus(v);
        }
        /// <summary>
        /// Update of the virus class attributes in the patient list
        /// </summary>
        /// <param name="index"></param>
        /// <param name="v"></param>
        /// <returns></returns>
        public static bool UpdatePerson(int index, VirusBO v)
        {
            return Virus.UpdateVirus(index, v);
        }

    }
}
