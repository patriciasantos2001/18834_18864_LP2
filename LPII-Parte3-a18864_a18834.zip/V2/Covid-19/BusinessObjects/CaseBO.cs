﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObjects
{
    public class CaseBO
    {
        #region ATTRIBUTES
        private static int countInfected;
        private static int countSuspected;
        private static int countDead;
        private static int countCured;
        #endregion

        #region CONSTRUCTORS
        //empty constructor
        public CaseBO()
        {

        }
        #endregion

        #region PROPERTIES
        /// <summary>
        /// Handle infected counter attribute
        /// </summary>
        public int CountInfected
        {
            get => countInfected;
        }

        /// <summary>
        /// Handle suspected counter attribute
        /// </summary>
        public int CountSuspected
        {
            get => countSuspected;
        }

        /// <summary>
        /// Handle dead counter attribute
        /// </summary>
        public int CountDead
        {
            get => countDead;
        }

        /// <summary>
        /// Handle cured counter attribute
        /// </summary>
        public int CountCured
        {
            get => countCured;
        }
        #endregion

        /// <summary>
        /// Case counter by situation
        /// </summary>
        /// <param name="patients"></param>
        public static void CountCases(List<PatientBO> patients)
        {
            List<PatientBO> auxPatients;
            auxPatients = patients.FindAll(p => p.Situacion == "Cured");
            countCured = auxPatients.Count;
            auxPatients = patients.FindAll(p => p.Situacion == "Infected");
            countInfected = auxPatients.Count;
            auxPatients = patients.FindAll(p => p.Situacion == "Suspected");
            countSuspected = auxPatients.Count;
            auxPatients = patients.FindAll(p => p.Situacion == "Dead");
            countDead = auxPatients.Count;

        }
    }
}
