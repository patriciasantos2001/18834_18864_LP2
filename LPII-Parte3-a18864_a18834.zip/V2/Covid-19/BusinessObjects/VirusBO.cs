﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObjects
{
    public enum Symptoms
    {
        FEVER = 1,
        MUSCLE_ACHES = 2,
        COUGH = 3,
        WEAKNESS = 4,
        RESPIRATORY_DIFFICULTIES = 5
    }

    public enum TestResult
    {
        POSITIVE = 1,
        NEGATIVE = 2
    }

    public class VirusBO
    {
        #region ATTRIBUTES
        string prognostic;
        string results;
        #endregion

        #region CONSTRUCTORS
        //empty constructor
        public VirusBO()
        {

        }
        #endregion

        #region PROPERTIES

        /// <summary>
        /// Handle prognostic attribute
        /// </summary>
        public string Prognostic
        {
            get => prognostic;
        }
        /// <summary>
        /// Handle results attribute
        /// </summary>
        public string Results
        {
            get => results;
        }
        /// <summary>
        /// Handle prognostic attribute
        /// </summary>
        public Symptoms PrognosticVirus
        {
            set
            {
                if (value == Symptoms.FEVER)
                {
                    prognostic = "Fever";
                }
                else if (value == Symptoms.MUSCLE_ACHES)
                {
                    prognostic = "Muscle Aches";
                }
                else if (value == Symptoms.COUGH)
                {
                    prognostic = "Cough";
                }
                else if (value == Symptoms.RESPIRATORY_DIFFICULTIES)
                {
                    prognostic = "Respiratory Difficulties";
                }
                else if (value == Symptoms.WEAKNESS)
                {
                    prognostic = "Weakness";
                }
            }
        }
        /// <summary>
        /// Handle test result attribute
        /// </summary>
        public TestResult ResultTest
        {
            set
            {
                if (value == TestResult.NEGATIVE)
                {
                    results = "Negative";
                }
                else if (value == TestResult.POSITIVE)
                {
                    results = "Positive";
                }
            }
        }
        #endregion
    }
    }
