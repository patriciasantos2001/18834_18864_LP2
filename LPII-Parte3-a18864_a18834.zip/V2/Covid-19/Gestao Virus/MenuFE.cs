﻿using System;
using BusinessRules;
using BusinessObjects;
using System.Collections.Generic;
using System.Text;
using DataAccess;
using System.Threading;

namespace Gestao_Virus
{
    public class MenuFE
    {
        /// <summary>
        /// Person Menu
        /// </summary>
        /// <param name="pt"></param>
        /// <param name="listPatients"></param>
        /// <param name="d"></param>
        /// <param name="listDoctor"></param>
        public static void Menu(PatientBO pt, List<PatientBO> listPatients, DoctorBO d, List<DoctorBO> listDoctor)
        {
            ConsoleKeyInfo number;
            do
            {
                Console.Clear();
                Console.WriteLine(" Person Menu\n(Insert an option)\n");
                Console.WriteLine(" [ 1 ]  Patient\n [ 2 ]  Doctor\n [ESC]  Exit");

                number = Console.ReadKey();

                Console.Clear();

                switch (number.Key)
                {
                    case ConsoleKey.D1:
                        MenuPatient(pt, listPatients);
                        break;

                    case ConsoleKey.D2:
                        MenuDoctor(d, listDoctor);
                        break;

                    default:
                        break;
                }
            } while (number.Key != ConsoleKey.Escape);
        }
        /// <summary>
        /// Patient Menu
        /// </summary>
        /// <param name="pt"></param>
        /// <param name="listPatients"></param>
        #region MENU_PATIENT
        public static void MenuPatient(PatientBO pt, List<PatientBO> listPatients)
        {
            ConsoleKeyInfo number;
            int option = 0;
            bool aux;
            int code = 0;
            // Show patients list
            listPatients = PatientBR.ShowPatients();
            do
            {
                Console.Clear();
                Console.WriteLine(" Patient Menu\n(Insert an opcion)\n");
                Console.WriteLine(" [ 1 ]  Insert Patient\n [ 2 ]  List Patients\n [ 3 ]  Edit Patient\n [ 4 ]  Search Patient Register\n [ 5 ]  Infected\n [ 6 ]  Suspected\n [ 7 ]  Cured\n [ 8 ]  Dead\n [ 9 ]  Situacion\n [Backspace]  Back");

                number = Console.ReadKey();
                Console.Clear();
                switch (number.Key)
                {
                    case ConsoleKey.D1:
                        #region D1
                        do
                        {
                            Console.WriteLine("--------------------");
                            Console.WriteLine(" New Patient Data");
                            Console.WriteLine("--------------------\n");
                            Console.WriteLine(" Doctor Code:");
                            aux = int.TryParse(Console.ReadLine(), out code);
                            if (aux)
                            {
                                if (DoctorBR.ExistDoctor(code))
                                {
                                    Console.WriteLine(" How many patients do you want to insert?");
                                    option = int.Parse(Console.ReadLine());

                                    for (int i = 0; i < option; i++)
                                    {
                                        Console.WriteLine("\n Patient {0}:\n", i + 1);
                                        pt = PatientFE.PatientData(pt, code);
                                        aux = PatientBR.InsertPatient(pt);

                                        InsertedVerify(aux);
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("Doesn't exist doctor");
                                    Console.ReadKey();
                                }
                            }
                            else
                            {
                                Console.Clear();
                                Console.WriteLine("Invalid Code");
                            }
                        } while (!aux);
                        break;
                    #endregion
                    case ConsoleKey.D2:
                        MenuList(pt, listPatients);
                        break;
                    case ConsoleKey.D3:
                        MenuEdit(pt, listPatients);
                        break;
                    case ConsoleKey.D4:
                        #region D4
                        Console.WriteLine(" Insert patient code:\n");
                        code = int.Parse(Console.ReadLine());

                        listPatients = PatientBR.ShowPatients();
                        if (listPatients.Count == 0)
                        {
                            Console.WriteLine("There are not patients on the list!");
                            Console.ReadKey();
                            break;
                        }

                        for (int i = 0; i < listPatients.Count; i++)
                        {
                            if (code == listPatients[i].CodePerson)
                            {
                                Console.Clear();
                                Console.WriteLine("-------------------------------");
                                Console.WriteLine("      Patient Info\n");
                                Console.WriteLine("-------------------------------");
                                Console.WriteLine(listPatients[i].ToString());
                                Console.WriteLine("-------------------------------");
                            }
                            else   Console.WriteLine("Invalid Code!");
                        }
                        Console.ReadKey();
                        break;
                    #endregion
                    case ConsoleKey.D5:
                        MenuInfected(pt, listPatients);
                        break;
                    case ConsoleKey.D6:
                        MenuSuspected(pt, listPatients);
                        break;
                    case ConsoleKey.D7:
                        MenuCured(pt, listPatients);
                        break;
                    case ConsoleKey.D8:
                        MenuDead(pt, listPatients);
                        break;
                    case ConsoleKey.D9:
                        CaseBO countCase = new CaseBO();
                        CaseBO.CountCases(listPatients);
                        Console.WriteLine(" Virus Situacion:\n");
                        Console.WriteLine(" -------------------------------");
                        Console.WriteLine(" Infected:\t{0}", countCase.CountInfected);
                        Console.WriteLine(" Suspected:\t{0}", countCase.CountSuspected);
                        Console.WriteLine(" Cured:\t{0}", countCase.CountCured);
                        Console.WriteLine(" Dead:\t{0}", countCase.CountDead);
                        Console.WriteLine("\n Total of person:\t{0}", listPatients.Count);
                        Console.ReadKey();
                        break;
                    default:
                        break;
                }
            } while (number.Key != ConsoleKey.Backspace);
        }
        /// <summary>
        /// Verifies if it is successfully inserted
        /// </summary>
        /// <param name="aux"></param>
        private static void InsertedVerify(bool aux)
        {
            if (aux == true)
            {
                //listar dados
                Console.WriteLine("\nSuccessfully Inserted!\n");
            }
            else
            {
                Console.WriteLine("\nUnsuccessfully Inserted!\n");
            }
        }
        /// <summary>
        /// Edit Menu
        /// </summary>
        /// <param name="pt"></param>
        /// <param name="listPatients"></param>
        #region MENU_EDIT
        public static void MenuEdit(PatientBO pt, List<PatientBO> listPatients)
        {
            ConsoleKeyInfo number;
            int code;
            
            do
            {
                Console.Clear();
                Console.WriteLine(" Edit Data Menu\n(Insert an option)\n");
                Console.WriteLine(" [ 1 ]  Edit Condition\n [ 2 ]  Edit Residence\n [ 3 ]  Edit Gender\n [ 4 ]  Edit Symptoms\n [ 5 ]  Edit Test Results\n [Backspace]  Back");

                number = Console.ReadKey();
                Console.Clear();
                listPatients = PatientBR.ShowPatients();

                switch (number.Key)
                {
                    case ConsoleKey.D1:
                        Console.WriteLine(" Insert patient code:\n");
                        code = int.Parse(Console.ReadLine());

                        for (int i = 0; i < listPatients.Count; i++)
                        {
                            if (code == listPatients[i].CodePatient)
                            {
                                if (PersonBR.UpdatePerson(i, PatientFE.AssignSituacion(listPatients[i])))
                                {
                                    Console.WriteLine(" Update Successful!");
                                }
                                else
                                {
                                    Console.WriteLine(" Update Unsuccessful!");
                                }
                                break;
                            }
                        }
                        Console.ReadKey();
                        break;

                    case ConsoleKey.D2:
                        Console.WriteLine(" Insert patient code:\n");
                        code = int.Parse(Console.ReadLine());

                        for (int i = 0; i < listPatients.Count; i++)
                        {
                            if (code == listPatients[i].CodePatient)
                            {
                                if (PersonBR.UpdatePerson(i, PersonFE.AssignResidence(listPatients[i])))
                                {
                                    Console.WriteLine(" Update Successful!");
                                }
                                else
                                {
                                    Console.WriteLine(" Update Unsuccessful!");
                                }
                                break;
                            }
                        }
                        Console.ReadKey();
                        break;

                    case ConsoleKey.D3:
                        Console.WriteLine(" Insert patient code:\n");
                        code = int.Parse(Console.ReadLine());

                        for (int i = 0; i < listPatients.Count; i++)
                        {
                            if (code == listPatients[i].CodePatient)
                            {
                                if (PersonBR.UpdatePerson(i, PersonFE.AssignGender(listPatients[i])))
                                {
                                    Console.WriteLine(" Update Successful!");
                                }
                                else
                                {
                                    Console.WriteLine(" Update Unsuccessful!");
                                }
                                break;
                            }
                        }
                        Console.ReadKey();
                        break;

                    case ConsoleKey.D4:
                        bool aux;
                        listPatients = PatientBR.ShowPatients();
                        do
                        {
                            Console.WriteLine(" Insert patient code:\n");
                            aux = int.TryParse(Console.ReadLine(), out code);
                            if (aux)
                            {
                                for (int i = 0; i < listPatients.Count; i++)
                                {
                                    if (code == listPatients[i].CodePatient)
                                    {
                                        listPatients[i].Virus = VirusFE.AssignSymptoms(listPatients[i].Virus);
                                        if (PersonBR.UpdatePerson(i, listPatients[i]))
                                        {
                                            Console.WriteLine(" Update Successful!");
                                        }
                                        else
                                        {
                                            Console.WriteLine(" Update Unsuccessful!");
                                        }
                                        break;
                                    }
                                }
                                Console.ReadKey();
                            }
                            else
                            {
                                Console.WriteLine("Invalid");
                            }
                        } while (!aux);
                        break;
                    //case ConsoleKey.D5:
                    //    Console.WriteLine(" Insert patient code:\n");
                    //    code = int.Parse(Console.ReadLine());

                    //    for (int i = 0; i < listPatients.Count; i++)
                    //    {
                    //        if (code == listPatients[i].CodePerson)
                    //        {
                    //            if (PersonBR.UpdatePerson(i, VirusFE.AssignResults(listPatients[i])))
                    //            {
                    //                Console.WriteLine(" Update Successful!");
                    //            }
                    //            else
                    //            {
                    //                Console.WriteLine(" Update Unsuccessful!");
                    //            }
                    //            break;
                    //        }
                    //    }
                    //    Console.ReadKey();
                    //    break;
                    default:
                        break;
                }
            } while (number.Key != ConsoleKey.Backspace);
        }
        #endregion
        /// <summary>
        /// List Menu
        /// </summary>
        /// <param name="pt"></param>
        /// <param name="listPatients"></param>
        #region MENU_LIST
        public static void MenuList(PatientBO pt, List<PatientBO> listPatients)
        {
            ConsoleKeyInfo number;
            string residence;
            string gender;
            int age;
            do
            {
                Console.Clear();
                Console.WriteLine(" List Patient Data Menu\n(Insert an option)\n");
                Console.WriteLine(" [ 1 ]  List All\n [ 2 ]  List by Residence\n [ 3 ]  List by Gender\n [ 4 ]  List by Age\n [Backspace]  Back");

                number = Console.ReadKey();
                Console.Clear();

                switch (number.Key)
                {
                    case ConsoleKey.D1:
                        listPatients = PatientBR.ShowPatients();

                        Console.WriteLine(" -------------------------------");
                        Console.WriteLine("      Patient Info\n");

                        for (int i = 0; i < listPatients.Count; i++)
                        {
                            Console.WriteLine(" -------------------------------");
                            Console.WriteLine(listPatients[i].ToString());
                        }
                        Console.WriteLine("\n There is {0} patients.", listPatients.Count);
                        Console.ReadKey();
                        break;

                    case ConsoleKey.D2:
                        listPatients = PatientBR.ShowPatients();

                        residence = PersonFE.InsertResidence();

                        if (listPatients.Count == 0)
                        {
                            Console.WriteLine(" There are not patients on the list with that residence!");
                            Console.ReadKey();
                            break;
                        }

                        for (int i = 0; i < listPatients.Count; i++)
                        {
                            if (residence == listPatients[i].Residence)
                            {
                                Console.Clear();
                                Console.WriteLine(" -------------------------------");
                                Console.WriteLine("      Patient Info\n");
                                Console.WriteLine(" -------------------------------");
                                Console.WriteLine(listPatients[i].ToString());
                            }
                            else
                            {
                                Console.WriteLine("\n Invalid Residence!");
                            }
                        }
                        Console.ReadKey();
                        break;

                    case ConsoleKey.D3:
                        listPatients = PatientBR.ShowPatients();

                        gender = PersonFE.InsertGender();

                        if (listPatients.Count == 0)
                        {
                            Console.WriteLine("\n There are not patients on the list with that gender!");
                            Console.ReadKey();
                            break;
                        }

                        for (int i = 0; i < listPatients.Count; i++)
                        {
                            if (gender == listPatients[i].Gender)
                            {
                                Console.Clear();
                                Console.WriteLine(" -------------------------------");
                                Console.WriteLine("      Patient Info\n");
                                Console.WriteLine(" -------------------------------");
                                Console.WriteLine(listPatients[i].ToString());
                            }
                            else
                            {
                                Console.WriteLine("\n Invalid Gender!");
                            }
                        }
                        Console.ReadKey();
                        break;

                    case ConsoleKey.D4:
                        listPatients = PatientBR.ShowPatients();

                        Console.WriteLine(" Insert age of patient:\n");
                        age = int.Parse(Console.ReadLine());

                        if (listPatients.Count == 0)
                        {
                            Console.WriteLine(" There are not patients on the list with that age!");
                            Console.ReadKey();
                            break;
                        }

                        for (int i = 0; i < listPatients.Count; i++)
                        {
                            if (age == listPatients[i].Age)
                            {
                                Console.Clear();
                                Console.WriteLine(" -------------------------------");
                                Console.WriteLine("      Patient Info\n");
                                Console.WriteLine(" -------------------------------");
                                Console.WriteLine(listPatients[i].ToString());
                            }
                            else
                            {
                                Console.WriteLine("\n Invalid Age!");
                            }
                        }
                        Console.ReadKey();
                        break;

                    default:
                        break;
                }
            } while (number.Key != ConsoleKey.Backspace);
        }
        #endregion

        #region MENU_SITUATION
        /// <summary>
        /// Situation Menu
        /// </summary>
        /// <param name="pt"></param>
        /// <param name="listPatients"></param>
        public static void MenuInfected(PatientBO pt, List<PatientBO> listPatients)
        {
            ConsoleKeyInfo number;
            string residence;
            string gender;
            int age;
            int count = 0;
            do
            {
                Console.Clear();
                Console.WriteLine(" Infected Menu\n(Insert an option)\n");
                Console.WriteLine(" [ 1 ]  List All\n [ 2 ]  List by Residence\n [ 3 ]  List by Gender\n [ 4 ]  List by Age\n [Backspace]  Back");

                number = Console.ReadKey();
                Console.Clear();

                switch (number.Key)
                {
                    case ConsoleKey.D1:
                        #region D1
                        listPatients = PatientBR.ShowPatients();

                        for (int i = 0; i < listPatients.Count; i++)
                        {
                            if (listPatients[i].Situacion == "Infected")
                            {
                                count++;
                                Console.WriteLine(listPatients[i].ToString());
                            }
                        }
                        Console.WriteLine("\n There is {0} cured patients.", count);
                        Console.ReadKey();
                        break;
                        #endregion
                    case ConsoleKey.D2:
                        Console.WriteLine(" Infected:");

                        listPatients = PatientBR.ShowPatients();

                        residence = PersonFE.InsertResidence();

                        if (listPatients.Count == 0)
                        {
                            Console.WriteLine(" There are not patients on the list with that residence!");
                            Console.ReadKey();
                            break;
                        }

                        for (int i = 0; i < listPatients.Count; i++)
                        {
                            if (residence == listPatients[i].Residence && listPatients[i].Situacion == "Infected")
                            {
                                count++;
                                Console.Clear();
                                Console.WriteLine(" -------------------------------");
                                Console.WriteLine("      Patient Info\n");
                                Console.WriteLine(" -------------------------------");
                                Console.WriteLine(listPatients[i].ToString());
                            }
                            else if (count == 0 && residence == listPatients[i].Residence && listPatients[i].Situacion != "Infected")
                            {
                                Console.WriteLine("\n There are patients with that location, but there are not infected!");
                            }
                        }
                        Console.ReadKey();
                        break;

                    case ConsoleKey.D3:
                        Console.WriteLine(" Infected:\n");

                        listPatients = PatientBR.ShowPatients();

                        gender = PersonFE.InsertGender();

                        if (listPatients.Count == 0)
                        {
                            Console.WriteLine("\n There are not patients on the list with that gender!");
                            Console.ReadKey();
                            break;
                        }

                        for (int i = 0; i < listPatients.Count; i++)
                        {
                            if (gender == listPatients[i].Gender && listPatients[i].Situacion == "Infected")
                            {
                                count++;
                                Console.Clear();
                                Console.WriteLine(" -------------------------------");
                                Console.WriteLine("      Patient Info\n");
                                Console.WriteLine(" -------------------------------");
                                Console.WriteLine(listPatients[i].ToString());
                            }
                            else if (count == 0 && gender == listPatients[i].Gender && listPatients[i].Situacion != "Infected")
                            {
                                Console.WriteLine("\n There are patients with that gender, but there are not infected!");
                            }
                        }
                        Console.ReadKey();
                        break;

                    case ConsoleKey.D4:
                        Console.WriteLine(" Infected:\n");

                        listPatients = PatientBR.ShowPatients();

                        Console.WriteLine(" Insert age of patient:\n");
                        age = int.Parse(Console.ReadLine());

                        if (listPatients.Count == 0)
                        {
                            Console.WriteLine(" There are not patients on the list with that age!");
                            Console.ReadKey();
                            break;
                        }

                        for (int i = 0; i < listPatients.Count; i++)
                        {
                            if (age == listPatients[i].Age && listPatients[i].Situacion == "Infected")
                            {
                                count++;
                                Console.Clear();
                                Console.WriteLine(" -------------------------------");
                                Console.WriteLine("      Patient Info\n");
                                Console.WriteLine(" -------------------------------");
                                Console.WriteLine(listPatients[i].ToString());
                            }
                            else if (count == 0 && age == listPatients[i].Age && listPatients[i].Situacion != "Infected")
                            {
                                Console.WriteLine("\n There are patients with that age, but there are not infected!");
                            }
                        }
                        Console.ReadKey();
                        break;

                    default:
                        break;
                }
            } while (number.Key != ConsoleKey.Backspace);
        }
        /// <summary>
        /// Suspected Menu
        /// </summary>
        /// <param name="pt"></param>
        /// <param name="listPatients"></param>
        public static void MenuSuspected(PatientBO pt, List<PatientBO> listPatients)
        {
            ConsoleKeyInfo number;
            string residence;
            string gender;
            int age;
            int count = 0;
            do
            {
                Console.Clear();
                Console.WriteLine(" Suspected Menu\n(Insert an option)\n");
                Console.WriteLine(" [ 1 ]  List All\n [ 2 ]  List by Residence\n [ 3 ]  List by Gender\n [ 4 ]  List by Age\n [Backspace]  Back");

                number = Console.ReadKey();
                Console.Clear();

                switch (number.Key)
                {
                    case ConsoleKey.D1:
                        listPatients = PatientBR.ShowPatients();

                        for (int i = 0; i < listPatients.Count; i++)
                        {
                            if (listPatients[i].Situacion == "Suspected")
                            {
                                count++;
                                Console.WriteLine(listPatients[i].ToString());
                            }
                        }
                        Console.WriteLine("\n There is {0} suspected patients.", count);
                        Console.ReadKey();
                        break;

                    case ConsoleKey.D2:
                        Console.WriteLine(" Suspected:");

                        listPatients = PatientBR.ShowPatients();
                        residence = PersonFE.InsertResidence();

                        if (listPatients.Count == 0)
                        {
                            Console.WriteLine(" There are not patients on the list with that residence!");
                            Console.ReadKey();
                            break;
                        }

                        for (int i = 0; i < listPatients.Count; i++)
                        {
                            if (residence == listPatients[i].Residence && listPatients[i].Situacion == "Suspected")
                            {
                                count++;
                                Console.Clear();
                                Console.WriteLine(" -------------------------------");
                                Console.WriteLine("      Patient Info\n");
                                Console.WriteLine(" -------------------------------");
                                Console.WriteLine(listPatients[i].ToString());
                            }
                            else if (count == 0 && residence == listPatients[i].Residence && listPatients[i].Situacion != "Suspected")
                            {
                                Console.WriteLine("\n There are patients with that location, but there aren't suspected!");
                            }
                        }
                        Console.ReadKey();
                        break;

                    case ConsoleKey.D3:
                        Console.WriteLine(" Suspected:\n");

                        listPatients = PatientBR.ShowPatients();
                        gender = PersonFE.InsertGender();

                        if (listPatients.Count == 0)
                        {
                            Console.WriteLine("\n There are not patients on the list with that gender!");
                            Console.ReadKey();
                            break;
                        }

                        for (int i = 0; i < listPatients.Count; i++)
                        {
                            if (gender == listPatients[i].Gender && listPatients[i].Situacion == "Suspected")
                            {
                                count++;
                                Console.Clear();
                                Console.WriteLine(" -------------------------------");
                                Console.WriteLine("      Patient Info\n");
                                Console.WriteLine(" -------------------------------");
                                Console.WriteLine(listPatients[i].ToString());
                            }
                            else if (count == 0 && gender == listPatients[i].Gender && listPatients[i].Situacion != "Suspected")
                            {
                                Console.WriteLine("\n There are patients with that gender, but there are not suspected!");
                            }
                        }
                        Console.ReadKey();
                        break;

                    case ConsoleKey.D4:
                        Console.WriteLine(" Suspected:\n");

                        listPatients = PatientBR.ShowPatients();

                        Console.WriteLine(" Insert age of patient:\n");
                        age = int.Parse(Console.ReadLine());

                        if (listPatients.Count == 0)
                        {
                            Console.WriteLine(" There are not patients on the list with that age!");
                            Console.ReadKey();
                            break;
                        }

                        for (int i = 0; i < listPatients.Count; i++)
                        {
                            if (age == listPatients[i].Age && listPatients[i].Situacion == "Suspected")
                            {
                                count++;
                                Console.Clear();
                                Console.WriteLine(" -------------------------------");
                                Console.WriteLine("      Patient Info\n");
                                Console.WriteLine(" -------------------------------");
                                Console.WriteLine(listPatients[i].ToString());
                            }
                            else if (count == 0 && age == listPatients[i].Age && listPatients[i].Situacion != "Suspected")
                            {
                                Console.WriteLine("\n There are patients with that age, but there are not infected!");
                            }
                        }
                        Console.ReadKey();
                        break;

                    default:
                        break;
                }
            } while (number.Key != ConsoleKey.Backspace);
        }
        /// <summary>
        /// Cured Menu
        /// </summary>
        /// <param name="pt"></param>
        /// <param name="listPatients"></param>
        public static void MenuCured(PatientBO pt, List<PatientBO> listPatients)
        {
            ConsoleKeyInfo number;
            string residence;
            string gender;
            int age;
            int count = 0;
            do
            {
                Console.Clear();
                Console.WriteLine(" Cured Menu\n(Insert an option)\n");
                Console.WriteLine(" [ 1 ]  List All\n [ 2 ]  List by Residence\n [ 3 ]  List by Gender\n [ 4 ]  List by Age\n [Backspace]  Back");

                number = Console.ReadKey();
                Console.Clear();

                switch (number.Key)
                {
                    case ConsoleKey.D1:
                        listPatients = PatientBR.ShowPatients();

                        for (int i = 0; i < listPatients.Count; i++)
                        {
                            if (listPatients[i].Situacion == "Cured")
                            {
                                count++;
                                Console.WriteLine(listPatients[i].ToString());
                            }
                        }
                        Console.WriteLine("\n There is {0} cured patients.", count);
                        Console.ReadKey();
                        break;

                    case ConsoleKey.D2:
                        Console.WriteLine(" Cured:");

                        listPatients = PatientBR.ShowPatients();

                        residence = PersonFE.InsertResidence();

                        if (listPatients.Count == 0)
                        {
                            Console.WriteLine(" There are not patients on the list with that residence!");
                            Console.ReadKey();
                            break;
                        }

                        for (int i = 0; i < listPatients.Count; i++)
                        {
                            if (residence == listPatients[i].Residence && listPatients[i].Situacion == "Cured")
                            {
                                count++;
                                Console.Clear();
                                Console.WriteLine(" -------------------------------");
                                Console.WriteLine("      Patient Info\n");
                                Console.WriteLine(" -------------------------------");
                                Console.WriteLine(listPatients[i].ToString());
                            }
                            else if (count == 0 && residence == listPatients[i].Residence && listPatients[i].Situacion != "Cured")
                            {
                                Console.WriteLine("\n There are patients with that location, but there are not cured!");
                            }
                        }
                        Console.ReadKey();
                        break;

                    case ConsoleKey.D3:
                        Console.WriteLine(" Cured:\n");

                        listPatients = PatientBR.ShowPatients();

                        gender = PersonFE.InsertGender();

                        if (listPatients.Count == 0)
                        {
                            Console.WriteLine("\n There are not patients on the list with that gender!");
                            Console.ReadKey();
                            break;
                        }

                        for (int i = 0; i < listPatients.Count; i++)
                        {
                            if (gender == listPatients[i].Gender && listPatients[i].Situacion == "Cured")
                            {
                                count++;
                                Console.Clear();
                                Console.WriteLine(" -------------------------------");
                                Console.WriteLine("      Patient Info\n");
                                Console.WriteLine(" -------------------------------");
                                Console.WriteLine(listPatients[i].ToString());
                            }
                            else if (count == 0 && gender == listPatients[i].Gender && listPatients[i].Situacion != "Cured")
                            {
                                Console.WriteLine("\n There are patients with that gender, but there are not cured!");
                            }
                        }
                        Console.ReadKey();
                        break;

                    case ConsoleKey.D4:
                        Console.WriteLine(" Cured:\n");

                        listPatients = PatientBR.ShowPatients();

                        Console.WriteLine(" Insert age of patient:\n");
                        age = int.Parse(Console.ReadLine());

                        if (listPatients.Count == 0)
                        {
                            Console.WriteLine(" There are not patients on the list with that age!");
                            Console.ReadKey();
                            break;
                        }

                        for (int i = 0; i < listPatients.Count; i++)
                        {
                            if (age == listPatients[i].Age && listPatients[i].Situacion == "Cured")
                            {
                                count++;
                                Console.Clear();
                                Console.WriteLine(" -------------------------------");
                                Console.WriteLine("      Patient Info\n");
                                Console.WriteLine(" -------------------------------");
                                Console.WriteLine(listPatients[i].ToString());
                            }
                            else if (count == 0 && age == listPatients[i].Age && listPatients[i].Situacion != "Cured")
                            {
                                Console.WriteLine("\n There are patients with that age, but there are not cured!");
                            }
                        }
                        Console.ReadKey();
                        break;

                    default:
                        break;
                }
            } while (number.Key != ConsoleKey.Backspace);
        }
        /// <summary>
        /// Dead Menu
        /// </summary>
        /// <param name="pt"></param>
        /// <param name="listPatients"></param>
        public static void MenuDead(PatientBO pt, List<PatientBO> listPatients)
        {
            ConsoleKeyInfo number;
            string residence;
            string gender;
            int age;
            int count = 0;
            do
            {
                Console.Clear();
                Console.WriteLine(" Dead Menu\n(Insert an option)\n");
                Console.WriteLine(" [ 1 ]  List All\n [ 2 ]  List by Residence\n [ 3 ]  List by Gender\n [ 4 ]  List by Age\n [Backspace]  Back");

                number = Console.ReadKey();
                Console.Clear();

                switch (number.Key)
                {
                    case ConsoleKey.D1:
                        listPatients = PatientBR.ShowPatients();

                        for (int i = 0; i < listPatients.Count; i++)
                        {
                            if (listPatients[i].Situacion == "Dead")
                            {
                                count++;
                                Console.WriteLine(listPatients[i].ToString());
                            }
                        }
                        Console.WriteLine("\n There is {0} dead patients.", count);
                        Console.ReadKey();
                        break;

                    case ConsoleKey.D2:
                        Console.WriteLine(" Dead:\n");

                        listPatients = PatientBR.ShowPatients();

                        residence = PersonFE.InsertResidence();

                        if (listPatients.Count == 0)
                        {
                            Console.WriteLine(" There are not patients on the list with that dead!");
                            Console.ReadKey();
                            break;
                        }

                        for (int i = 0; i < listPatients.Count; i++)
                        {
                            if (residence == listPatients[i].Residence && listPatients[i].Situacion == "Dead")
                            {
                                count++;
                                Console.Clear();
                                Console.WriteLine(" -------------------------------");
                                Console.WriteLine("      Patient Info\n");
                                Console.WriteLine(" -------------------------------");
                                Console.WriteLine(listPatients[i].ToString());
                            }
                            else if (count == 0 && residence == listPatients[i].Residence && listPatients[i].Situacion != "Dead")
                            {
                                Console.WriteLine("\n There are patients with that location, but there are not dead!");
                            }
                        }
                        Console.ReadKey();
                        break;

                    case ConsoleKey.D3:
                        Console.WriteLine(" Dead:\n");

                        listPatients = PatientBR.ShowPatients();

                        gender = PersonFE.InsertGender();

                        if (listPatients.Count == 0)
                        {
                            Console.WriteLine(" There are not patients on the list with that gender!");
                            Console.ReadKey();
                            break;
                        }

                        for (int i = 0; i < listPatients.Count; i++)
                        {
                            if (gender == listPatients[i].Gender && listPatients[i].Situacion == "Dead")
                            {
                                count++;
                                Console.Clear();
                                Console.WriteLine(" -------------------------------");
                                Console.WriteLine("      Patient Info\n");
                                Console.WriteLine(" -------------------------------");
                                Console.WriteLine(listPatients[i].ToString());
                            }
                            else if (count == 0 && gender == listPatients[i].Gender && listPatients[i].Situacion != "Dead")
                            {
                                Console.WriteLine("\n There are patients with that gender, but there are not dead!");
                            }
                        }
                        Console.ReadKey();
                        break;

                    case ConsoleKey.D4:
                        Console.WriteLine(" Dead:\n");

                        listPatients = PatientBR.ShowPatients();

                        Console.WriteLine(" Insert age of patient:\n");
                        age = int.Parse(Console.ReadLine());

                        if (listPatients.Count == 0)
                        {
                            Console.WriteLine(" There are not patients on the list with that age!");
                            Console.ReadKey();
                            break;
                        }

                        for (int i = 0; i < listPatients.Count; i++)
                        {
                            if (age == listPatients[i].Age && listPatients[i].Situacion == "Dead")
                            {
                                count++;
                                Console.Clear();
                                Console.WriteLine(" -------------------------------");
                                Console.WriteLine("      Patient Info\n");
                                Console.WriteLine(" -------------------------------");
                                Console.WriteLine(listPatients[i].ToString());
                            }
                            else if (count == 0 && age == listPatients[i].Age && listPatients[i].Situacion != "Dead")
                            {
                                Console.WriteLine("\n There are patients with that age, but there are not dead!");
                            }
                        }
                        Console.ReadKey();
                        break;

                    default:
                        break;
                }
            } while (number.Key != ConsoleKey.Backspace);
        }
        #endregion
        #endregion

        #region MENU_DOCTOR
        /// <summary>
        /// Doctor Menu
        /// </summary>
        /// <param name="d"></param>
        /// <param name="listDoctor"></param>
        public static void MenuDoctor(DoctorBO d, List<DoctorBO> listDoctor)
        {
            ConsoleKeyInfo number;
            int option = 0;
            bool aux;
            int code = 0;
            do
            {
                Console.Clear();
                Console.WriteLine(" Doctor Menu\n(Insert an option)\n");
                Console.WriteLine(" [ 1 ]  Insert Doctor\n [ 2 ]  List Doctors\n [ 3 ]  Edit Doctor\n [ 4 ]  Search Doctor Register\n [Backspace]  Back");

                number = Console.ReadKey();
                Console.Clear();

                switch (number.Key)
                {
                    case ConsoleKey.D1:
                        Console.WriteLine(" How many doctors do you want to insert?");
                        option = int.Parse(Console.ReadLine());

                        for (int i = 0; i < option; i++)
                        {
                            Console.WriteLine("\n Doctor {0}:", i + 1);
                            d = DoctorFE.DoctorData(d);
                            aux = DoctorBR.InsertDoctor(d);

                            if (aux == true)
                            {
                                //listar dados
                                Console.WriteLine("\n Sucessfully Inserted!\n");
                            }
                            else
                            {
                                Console.WriteLine("\n Unsucessfully Inserted!\n");
                            }
                        }
                        break;

                    case ConsoleKey.D2:
                        MenuList(d, listDoctor);
                        break;

                    case ConsoleKey.D3:
                        MenuEdit(d, listDoctor);
                        break;

                    case ConsoleKey.D4:
                        Console.WriteLine(" Insert doctor code:\n");
                        code = int.Parse(Console.ReadLine());

                        listDoctor = DoctorBR.ShowDoctor();
                        if (listDoctor.Count == 0)
                        {
                            Console.WriteLine(" There are not doctors on the list!");
                            Console.ReadKey();
                            break;
                        }

                        for (int i = 0; i < listDoctor.Count; i++)
                        {
                            if (code == listDoctor[i].CodeDoctor)
                            {
                                Console.Clear();
                                Console.WriteLine("-------------------------------");
                                Console.WriteLine("       Doctor Info\n");
                                Console.WriteLine("-------------------------------");
                                Console.WriteLine(listDoctor[i].ToString());
                            }
                            else
                            {
                                Console.WriteLine(" Invalid Code!");
                            }
                        }
                        Console.ReadKey();
                        break;
                    default:
                        break;
                }
            } while (number.Key != ConsoleKey.Backspace);
        }
        /// <summary>
        /// Edit Menu
        /// </summary>
        /// <param name="d"></param>
        /// <param name="listDoctor"></param>
        #region MENU_EDIT
        public static void MenuEdit(DoctorBO d, List<DoctorBO> listDoctor)
        {
            ConsoleKeyInfo number;
            int code;

            Console.Clear();
            Console.WriteLine(" Edit Data Menu\n(Insert an option)\n");
            Console.WriteLine(" [ 1 ]  Edit Residence\n [ 2 ]  Edit Specialty\n [ 3 ]  Edit Gender\n [Backspace]  Back");

            number = Console.ReadKey();
            Console.Clear();
            listDoctor = DoctorBR.ShowDoctor();

            do
            {
                switch (number.Key)
                {
                    case ConsoleKey.D1:
                        Console.WriteLine(" Insert doctor code:\n");
                        code = int.Parse(Console.ReadLine());

                        for (int i = 0; i < listDoctor.Count; i++)
                        {
                            if (code == listDoctor[i].CodePerson)
                            {
                                if (PersonBR.UpdatePerson(i, PersonFE.AssignResidence(listDoctor[i])))
                                {
                                    Console.WriteLine(" Update Successful!");
                                }
                                else
                                {
                                    Console.WriteLine(" Update Unsuccessful!");
                                }
                                break;
                            }
                        }
                        Console.ReadKey();
                        break;

                    case ConsoleKey.D2:
                        Console.WriteLine(" Insert doctor code:\n");
                        code = int.Parse(Console.ReadLine());

                        for (int i = 0; i < listDoctor.Count; i++)
                        {
                            if (code == listDoctor[i].CodePerson)
                            {
                                if (PersonBR.UpdatePerson(i, DoctorFE.AssignWork(listDoctor[i])))
                                {
                                    Console.WriteLine(" Update Successful!");
                                }
                                else
                                {
                                    Console.WriteLine(" Update Unsuccessful!");
                                }
                                break;
                            }
                        }
                        Console.ReadKey();
                        break;

                    case ConsoleKey.D3:
                        Console.WriteLine(" Insert doctor code:\n");
                        code = int.Parse(Console.ReadLine());

                        for (int i = 0; i < listDoctor.Count; i++)
                        {
                            if (code == listDoctor[i].CodePerson)
                            {
                                if (PersonBR.UpdatePerson(i, PersonFE.AssignGender(listDoctor[i])))
                                {
                                    Console.WriteLine(" Update Successful!");
                                }
                                else
                                {
                                    Console.WriteLine(" Update Unsuccessful!");
                                }
                                break;
                            }
                        }
                        Console.ReadKey();
                        break;
                    default:
                        break;
                }
            } while (number.Key != ConsoleKey.Backspace);            
        }
        #endregion
        /// <summary>
        /// List Menu
        /// </summary>
        /// <param name="d"></param>
        /// <param name="listDoctor"></param>
        #region MENU_LIST
        public static void MenuList(DoctorBO d, List<DoctorBO> listDoctor)
        {
            ConsoleKeyInfo number;
            string residence;
            string gender;
            int age;
            string specialty;
            do
            {
                Console.Clear();
                Console.WriteLine(" List Doctor Data Menu\n(Insert an option)\n");
                Console.WriteLine(" [ 1 ]  List All\n [ 2 ]  List by Residence\n [ 3 ]  List by Gender\n [ 4 ]  List by Age\n [ 5 ]  List by Specialty\n [Backspace]  Back");

                number = Console.ReadKey();
                Console.Clear();
                listDoctor = DoctorBR.ShowDoctor();
                switch (number.Key)
                {
                    case ConsoleKey.D1:
                        Console.WriteLine("-------------------------------");
                        Console.WriteLine("       Doctor Info\n");

                        for (int i = 0; i < listDoctor.Count; i++)
                        {
                            Console.WriteLine("-------------------------------");
                            Console.WriteLine(listDoctor[i].ToString());
                        }
                        Console.WriteLine("\n There is {0} doctors.", listDoctor.Count);
                        Console.ReadKey();
                        break;

                    case ConsoleKey.D2:
                        residence = PersonFE.InsertResidence();

                        if (listDoctor.Count == 0)
                        {
                            Console.WriteLine(" There are not doctors on the list with that residence!");
                            Console.ReadKey();
                            break;
                        }

                        for (int i = 0; i < listDoctor.Count; i++)
                        {
                            if (residence == listDoctor[i].Residence)
                            {
                                Console.Clear();
                                Console.WriteLine("-------------------------------");
                                Console.WriteLine("       Doctor Info\n");
                                Console.WriteLine("-------------------------------");
                                Console.WriteLine(listDoctor[i].ToString());
                            }
                            else
                            {
                                Console.WriteLine("\n There are not doctores with that residence!");
                            }
                        }
                        Console.ReadKey();
                        break;

                    case ConsoleKey.D3:
                        gender = PersonFE.InsertGender();

                        if (listDoctor.Count == 0)
                        {
                            Console.WriteLine("\n There are not doctors on the list with that gender!");
                            Console.ReadKey();
                            break;
                        }

                        for (int i = 0; i < listDoctor.Count; i++)
                        {
                            if (gender == listDoctor[i].Gender)
                            {
                                Console.Clear();
                                Console.WriteLine("-------------------------------");
                                Console.WriteLine("       Doctor Info\n");
                                Console.WriteLine("-------------------------------");
                                Console.WriteLine(listDoctor[i].ToString());
                            }
                            else
                            {
                                Console.WriteLine("\n There are not doctores with that gender!");
                            }
                        }
                        Console.ReadKey();
                        break;

                    case ConsoleKey.D4:
                        Console.WriteLine(" Insert age of doctor:\n");
                        age = int.Parse(Console.ReadLine());

                        if (listDoctor.Count == 0)
                        {
                            Console.WriteLine(" There are not doctors on the list with that age!");
                            Console.ReadKey();
                            break;
                        }

                        for (int i = 0; i < listDoctor.Count; i++)
                        {
                            if (age == listDoctor[i].Age)
                            {
                                Console.Clear();
                                Console.WriteLine("-------------------------------");
                                Console.WriteLine("       Doctor Info\n");
                                Console.WriteLine("-------------------------------");
                                Console.WriteLine(listDoctor[i].ToString());
                            }
                            else
                            {
                                Console.WriteLine("\n There are not doctores with that age!");
                            }
                        }
                        Console.ReadKey();
                        break;

                    case ConsoleKey.D5:
                        Console.WriteLine(" Insert doctor specialty:\n");
                        specialty = Console.ReadLine();

                        if (listDoctor.Count == 0)
                        {
                            Console.WriteLine(" There are not doctors on the list with that specialty!");
                            Console.ReadKey();
                            break;
                        }

                        for (int i = 0; i < listDoctor.Count; i++)
                        {
                            if (specialty == listDoctor[i].Work)
                            {
                                Console.Clear();
                                Console.WriteLine("-------------------------------");
                                Console.WriteLine("       Doctor Info\n");
                                Console.WriteLine("-------------------------------");
                                Console.WriteLine(listDoctor[i].ToString());
                            }
                            else
                            {
                                Console.WriteLine("\n There are not doctores with that specialty!");
                            }
                        }
                        Console.ReadKey();
                        break;
                    default:
                        break;
                }
            } while (number.Key != ConsoleKey.Backspace);
        }
        #endregion

        #endregion
    }
}
