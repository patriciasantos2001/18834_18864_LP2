﻿using System;
using System.Collections.Generic;
using System.Text;
using BusinessObjects;

namespace Gestao_Virus
{
    class VirusFE
    {
        /// <summary>
        /// Ask for person-virus data
        /// </summary>
        /// <param name="v"></param>
        public static VirusBO VirusData(VirusBO v)
        {
            //Insert Symptoms
            v = AssignSymptoms(v);

            //Insert Reslt of Test
            v = AssignResults(v);

            return v;
        }

        /// <summary>
        /// Insert Symptoms automatically
        /// </summary>
        /// <param name="v"></param>
        public static VirusBO AssignSymptoms(VirusBO v)
        {
            ConsoleKeyInfo residenceKey;

            do
            {
                Console.WriteLine("\n\nInsert symptoms of patient");
                Console.WriteLine("[1] Fever \n[2] Muscle Aches \n[3] Cough \n[4] Respiratory Difficulties \n[5] Weakness");
                residenceKey = Console.ReadKey();

                switch (residenceKey.Key)
                {
                    case ConsoleKey.D1:
                        v.PrognosticVirus = Symptoms.FEVER;
                        break;
                    case ConsoleKey.D2:
                        v.PrognosticVirus = Symptoms.MUSCLE_ACHES;
                        break;
                    case ConsoleKey.D3:
                        v.PrognosticVirus = Symptoms.COUGH;
                        break;
                    case ConsoleKey.D4:
                        v.PrognosticVirus = Symptoms.RESPIRATORY_DIFFICULTIES;
                        break;
                    case ConsoleKey.D5:
                        v.PrognosticVirus = Symptoms.WEAKNESS;
                        break;
                    default:
                        Console.WriteLine("\nInvalid Value!");
                        break;
                }
            } while (residenceKey.Key != ConsoleKey.D1 && residenceKey.Key != ConsoleKey.D2 && residenceKey.Key != ConsoleKey.D3 && residenceKey.Key != ConsoleKey.D4 && residenceKey.Key != ConsoleKey.D5);
            return v;
        }

        /// <summary>
        /// Insert Symptoms
        /// </summary>
        /// <returns></returns>
        public static string InsertSymptoms()
        {
            string sympt = "";
            ConsoleKeyInfo symptKey;

            do
            {
                Console.WriteLine("\n\nInsert symptoms of patient");
                Console.WriteLine("[1] Fever \n[2] Muscle Aches \n[3] Cough \n[4] Respiratory Difficulties \n[5] Weakness");
                symptKey = Console.ReadKey();

                switch (symptKey.Key)
                {
                    case ConsoleKey.D1:
                        sympt = "Fever";
                        break;
                    case ConsoleKey.D2:
                        sympt = "Muscle Aches";
                        break;
                    case ConsoleKey.D3:
                        sympt = "Cough";
                        break;
                    case ConsoleKey.D4:
                        sympt = "Respiratory Difficulties";
                        break;
                    case ConsoleKey.D5:
                        sympt = "Weakness";
                        break;
                    default:
                        Console.WriteLine("\nInvalid Value!");
                        break;
                }
            } while (symptKey.Key != ConsoleKey.D1 && symptKey.Key != ConsoleKey.D2 && symptKey.Key != ConsoleKey.D3 && symptKey.Key != ConsoleKey.D4 && symptKey.Key != ConsoleKey.D5);
            return sympt;
        }
        /// <summary>
        /// Insert Results automatically
        /// </summary>
        /// <param name="v"></param>
        /// <returns></returns>
        public static VirusBO AssignResults(VirusBO v)
        {
            ConsoleKeyInfo resultsKey;

            do
            {
                Console.WriteLine("\n\nInsert results of test");
                Console.WriteLine("[1] Positive \n[2] Negative");
                resultsKey = Console.ReadKey();

                switch (resultsKey.Key)
                {
                    case ConsoleKey.D1:
                        v.ResultTest = TestResult.POSITIVE;
                        break;
                    case ConsoleKey.D2:
                        v.ResultTest = TestResult.NEGATIVE;
                        break;
                    default:
                        Console.WriteLine("\nInvalid Value!");
                        break;
                }
            } while (resultsKey.Key != ConsoleKey.D1 && resultsKey.Key != ConsoleKey.D2);
            return v;
        }
        /// <summary>
        /// Insert Results
        /// </summary>
        /// <returns></returns>
        public static string InsertResults()
        {
            string result = "";
            ConsoleKeyInfo resultKey;

            do
            {
                Console.WriteLine("\n\nInsert results of teste");
                Console.WriteLine("[1] Positive \n[2] Negative");
                resultKey = Console.ReadKey();

                switch (resultKey.Key)
                {
                    case ConsoleKey.D1:
                        result = "Positive";
                        break;
                    case ConsoleKey.D2:
                        result = "Negative";
                        break;
                    default:
                        Console.WriteLine("\nInvalid Value!");
                        break;
                }
            } while (resultKey.Key != ConsoleKey.D1 && resultKey.Key != ConsoleKey.D2);
            return result;
        }
    }
}
