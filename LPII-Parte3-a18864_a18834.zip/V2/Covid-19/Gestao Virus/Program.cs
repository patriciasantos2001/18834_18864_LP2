﻿using System;
using BusinessObjects;
using BusinessRules;
using System.Collections;
using System.Collections.Generic;
using System.Net.NetworkInformation;
using System.Threading;

namespace Gestao_Virus
{
    public class Program
    {
        static void Main(string[] args)
        {
            PersonBO p = new PersonBO();
            PatientBO pt = new PatientBO();
            DoctorBO d = new DoctorBO();
            List<PatientBO> listPatients = new List<PatientBO>();
            List<DoctorBO> listDoctor = new List<DoctorBO>();
            DoctorBR.LoadDoctorFile();
            PatientBR.LoadPatientFile();
            MenuFE.Menu(pt, listPatients, d, listDoctor);
            DoctorBR.SaveDoctorFile();
            PatientBR.SavePatientFile();
        }
    }
}
