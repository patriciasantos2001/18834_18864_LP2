﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gestão_de_Vírus
{
    public enum Sintomas
    {
        FEBRE,
        DORES_MUSCULARES,
        TOSSE,
        FRAQUEZA,
        DIFICULDADES_RESPIRATORIAS
    }

    public enum ResultadoTeste
    {
        POSITIVO,
        NEGATIVO
    }

    public class Virus
    {
        #region ATRIBUTOS

        static Sintomas sint;
        ResultadoTeste resultados;

        #endregion

        #region CONSTRUTORES

        #endregion

        #region PROPRIEDADES
        public Sintomas Sint
        {
            get { return sint; }
            set { sint = value; }
        }

        public ResultadoTeste Resultados
        {
            get { return resultados; }
            set { resultados = value; }
        }
        #endregion

        #region METODOS
        /// <summary>
        /// Inserir Sintomas do Paciente
        /// </summary>
        /// <param name=""></param>
        /// <returns>Pede ao utilizador os dados do paciente</returns>
        public static Sintomas AtribuirSintomas(Paciente p)
        {
            int opcao;

            if (p.Situacao == Estado.INFETADO || p.Situacao == Estado.SUSPEITO)
            {
                Console.WriteLine("Qual os sintomas do paciente?");
                Console.WriteLine("[1] Dificuldades Respiratórias \n[2] Dores Musculares \n[3] Febre \n[4] Fraqueza \n[5] Tosse\n");
                opcao = int.Parse(Console.ReadLine());

                if (opcao == 1)
                {
                    return Sintomas.DIFICULDADES_RESPIRATORIAS;
                }
                else if (opcao == 2)
                {
                    return Sintomas.DORES_MUSCULARES;
                }
                else if (opcao == 3)
                {
                    return Sintomas.FEBRE;
                }
                else if (opcao == 4)
                {
                    return Sintomas.FRAQUEZA;
                }
                else if (opcao == 5)
                {
                    return Sintomas.TOSSE;
                }
                else if (opcao != 1 || opcao != 2 || opcao != 3 || opcao != 4 || opcao != 5)
                {
                    Console.WriteLine("O valor inserido não é válido.\nReinsira-o.");
                    opcao = int.Parse(Console.ReadLine());
                }
            }
            return sint;
        }

        #endregion
    }
}
