﻿using System;
using System.Collections.Generic;
using System.Reflection.Metadata.Ecma335;
using System.Text;

namespace Gestão_de_Vírus
{
    public enum Estado
    {
        CURADO,
        INFETADO,
        SUSPEITO,
        MORTO
    }

    class Paciente : Pessoa
    {
        #region ATRIBUTOS

        int codigoPaciente;
        int codigoMedico;
        DateTime entradaHospital;
        static Estado situacao;
        Virus[] virus;

        static Paciente[] paciente = new Paciente[10];
        static int numPaciente = 0;

        #endregion

        #region CONSTRUTORES
        #endregion

        #region PROPRIEDADES
        public int CodigoPaciente
        {
            get { return (new Random().Next(1000, 9999)); }
        }

        public int CodigoMedico
        {
            get { return (new Random().Next(1000, 9999)); }
        }

        public Estado Situacao
        {
            get { return situacao; }
            set { situacao = value; }
        }
        #endregion

        #region OVERRIDE
        /// <summary>
        /// Output dos dados
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return string.Format("Data Entrada: {0}/{1}/{2}\n\tNome: {3}\n\tIdade: {4}\n\tData Nascimento: {5}/{6}/{7}\n\tGenero: {8}\n\t" +
                                   "Local de Residencia: {9}\n\tEstado: {10}\n\tSintomas: \n\tCodigo: \n",
                        DateTime.Now.Day, DateTime.Now.Month, DateTime.Now.Year, Nome, Idade, DataNascimento.Day,
                        DataNascimento.Month, DataNascimento.Year, Sexo, LocalResidencia, Situacao);
        }
        #endregion

        #region METODOS

        /// <summary>
        /// Inserir paciente
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        public static int InserirP(Paciente p, Virus v)
        {
            Boolean auxDate;
            DateTime dataN;

            //Inserir nome
            Console.WriteLine("Insira o nome do paciente:");
            p.Nome = Console.ReadLine();

            //Inserir Data de Nascimento
            Console.WriteLine("Insira a data de nascimento do paciente:");
            auxDate = DateTime.TryParse(Console.ReadLine(), out dataN);
            p.DataNascimento = dataN;
            if (auxDate != true)
            {
                Console.WriteLine("Data inválida");
            }

            //Inserir Idade
            p.Idade = Pessoa.AtribuirIdade();

            //Inserir o Género
            p.Sexo = Pessoa.AtribuiGenero();

            //Inserir o local de residência
            p.LocalResidencia = Pessoa.AtribuirResidencia();

            //Atribui o estado do paciente
            p.Situacao = AtribuirEstado();

            //Atribui os sintomas do paciente
            v.Sint = Virus.AtribuirSintomas(p);

            return p;
        }

        /// <summary>
        /// Inserir o estado do paciente
        /// </summary>
        /// <param name=""></param>
        /// <returns>Pede ao utilizador os dados do paciente</returns>
        public static Estado AtribuirEstado()
        {
            int opcao;

            Console.WriteLine("Qual o estado do paciente?");
            Console.WriteLine("[1] Infetado \n[2] Suspeito \n[3] Morto \n[4] Curado\n");
            opcao = int.Parse(Console.ReadLine());

            if (opcao == 1)
            {
                return Estado.INFETADO;
            }
            else if (opcao == 2)
            {
                return Estado.SUSPEITO;
            }
            else if (opcao == 3)
            {
                return Estado.MORTO;
            }
            else if (opcao == 4)
            {
                return Estado.CURADO;
            }
            else if (opcao != 1 ||  opcao != 2 || opcao != 3 || opcao != 4)
            {
                Console.WriteLine("O valor inserido não é válido.\n Reinsira-o.");
                opcao = int.Parse(Console.ReadLine());
            }
            return situacao;
        }

        /// <summary>
        /// Verifica se determinado paciente existe
        /// </summary>
        /// <param name="nome"></param>
        /// <returns></returns>
        public static bool ExistePaciente(string nome)
        {
            for (int i = 0; i < numPaciente; i++)
            {
                if (paciente[i].Nome.CompareTo(nome) == 0)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Regista um novo paciente
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        public static int InserePaciente(Paciente p)
        {
            //Testar se está cheio
            if (numPaciente >= 10) return 0;
            //testar se já existe; 
            if (ExistePaciente(p.Nome)) return 0;
            //ou
            //if (totPessoas >= MAX || GetPessoa(p.Idade) != null) return 0;

            paciente[numPaciente++] = p;
            return 1;
        }

        /// <summary>
        /// Procura a ficha de determinado paciente ...
        /// </summary>
        /// <param name="id">Nome da pessoa</param>
        /// <returns>Ficha da Pessoa</returns>
        public static Paciente GetPaciente(int id)
        {
            for (int i = 0; i < numPaciente; i++)
            {
                if (paciente[i] != null && paciente[i].Idade == id) return paciente[i];
            }
            return null;
        }

        /// <summary>
        /// Mostrar a ficha de determinado paciente
        /// </summary>
        /// <param name="id">Nome da pessoa</param>
        public static Paciente MostrarPaciente()
        {
            int j = 0;

            while (j < paciente.Length)
            {
                Console.WriteLine("Paciente [{0}]={1}", j, paciente[j]);
                j++;
            }
            return paciente[j];
        }

        
        #endregion
    }
}
