﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gestão_de_Vírus
{
    public enum Genero
    {
        FEMININO,
        MASCULINO
    }

    public enum Residencia
    {
        AÇORES,
        ALGARVE,
        LISBOA,
        MADEIRA,
        PORTO
    }

    class Pessoa
    {
        #region ATRIBUTOS

        string nome;
        static int idade;
        static DateTime dataNascimento;
        static Genero sexo;
        static Residencia localResidencia;

        #endregion

        #region CONSTRUTORES

        #endregion

        #region PROPRIEDADES

        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }

        public DateTime DataNascimento
        {
            get { return dataNascimento; }
            set
            {
                DateTime aux;
                if (DateTime.TryParse(value.ToString(), out aux) == true) { dataNascimento = value; }
            }
        }

        public int Idade
        {
            get => idade;
            set => idade = value;
        }

        public Genero Sexo
        {
            get { return sexo; }
            set { sexo = value; }
        }

        public Residencia LocalResidencia
        {
            get { return localResidencia; }
            set { localResidencia = value; }
        }

        #endregion

        #region METODOS
        /// <summary>
        /// Atribuir idade. 
        /// </summary>
        /// <param name="dataNascimento">Data de Nascimento</param>
        /// <returns></returns>
        public static int AtribuirIdade()
        {
            int anoAtual;
            int anoNasciemnto;

            if (int.TryParse(DateTime.Today.Year.ToString(), out anoAtual))
            {
                if (int.TryParse(dataNascimento.Year.ToString(), out anoNasciemnto))
                {
                    if (dataNascimento.Month == DateTime.Today.Month)
                    {
                        if (dataNascimento.Day < DateTime.Today.Day)
                        {
                            anoAtual -= 1;
                        }
                    }
                    else if (dataNascimento.Month > dataNascimento.Day)
                    {
                        anoAtual -= 1;
                    }
                    idade = anoAtual - anoNasciemnto;
                }
            }
            return idade;
        }

        /// <summary>
        /// Atribuir genero. 
        /// </summary>
        /// <param name="dataNascimento">Data de Nascimento</param>
        /// <returns></returns>
        public static Genero AtribuiGenero()
        {
            int opcao;
            Console.WriteLine("Insira o genero do paciente:\n");
            Console.WriteLine("[1] Feminino \n[2] Masculino\n");
            opcao = int.Parse(Console.ReadLine());

            if (opcao == 1)
            {
                return Genero.FEMININO;
            }
            else if (opcao == 2)
            {
                return Genero.MASCULINO;
            }
            else if (opcao != 1 || opcao != 2)
            {
                Console.WriteLine("O valor inserido não é válido.\nInsira novamente.");
                opcao = int.Parse(Console.ReadLine());
            }
            return sexo;
        }

        /// <summary>
        /// Atribuir local de residencia. 
        /// </summary>
        /// <param name="dataNascimento">Data de Nascimento</param>
        /// <returns></returns>
        public static Residencia AtribuirResidencia()
        {
            int opcao;

            Console.WriteLine("Insira o local de residência do paciente\n");
            Console.WriteLine("[1] Açores \n[2] Algarve \n[3] Lisboa \n[4] Madeira \n[5] Porto\n");
            opcao = int.Parse(Console.ReadLine());

            if (opcao == 1)
            {
                return Residencia.AÇORES;
            }
            else if (opcao == 2)
            {
                return Residencia.ALGARVE;
            }
            else if (opcao == 3)
            {
                return Residencia.LISBOA; 
            }
            else if (opcao == 4)
            {
                return Residencia.MADEIRA;
            }
            else if (opcao == 5)
            {
                return Residencia.PORTO;
            }
            else if (opcao != 1 || opcao != 2 || opcao != 3 || opcao != 4 || opcao != 5)
            {
                Console.WriteLine("O valor inserido não é válido.\nReinsira-o novamente.");
                opcao = int.Parse(Console.ReadLine());
            }
            return localResidencia;
        }

       
        #endregion
    }
}
