﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gestão_de_Vírus
{
    public enum Especialidade
    {
        NEUROLOGIA,
        CARDIOLOGIA,
        PEDIATRIA,
        CIRURGIA,
        OBSTETRICIA,
        ORTOPEDIA
    }

    class Medico : Pessoa
    {
        #region ATRIBUTOS

        Especialidade trabalho;
        int codigoMedico;
        Paciente[] paciente;

        static Medico[] medico = new Medico[10];
        static int numMedico = 0;

        #endregion

        #region CONSTRUTORES
        #endregion

        #region PROPRIEDADES

        public int CodigoMedico
        {
            get { return (new Random().Next(1000, 9999)); }
        }

        public Especialidade Trabalho
        {
            get { return trabalho; }
            set { trabalho = value; }
        }
        #endregion

        #region METODOS

        /// <summary>
        /// Verifica se determinado medico existe
        /// </summary>
        /// <param name="nome"></param>
        /// <returns></returns>
        public static bool ExisteMedico(string nome)
        {
            for (int i = 0; i < numMedico; i++)
            {
                if (medico[i].Nome.CompareTo(nome) == 0)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Regista um novo medico
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        public static int InsereMedico(Medico m)
        {
            //Testar se está cheio
            if (numMedico >= 10) return 0;
            //testar se já existe; 
            if (ExisteMedico(m.Nome)) return 0;
            //ou
            //if (totPessoas >= MAX || GetPessoa(p.Idade) != null) return 0;

            medico[numMedico++] = m;
            return 1;
        }

        /// <summary>
        /// Procura a ficha de determinado medico
        /// </summary>
        /// <param name="id">Nome da pessoa</param>
        /// <returns>Ficha da Pessoa</returns>
        public static Pessoa GetMedico(int id)
        {
            for (int i = 0; i < numMedico; i++)
            {
                if (medico[i] != null && medico[i].Idade == id) return medico[i];
            }
            return null;
        }

        #endregion
    }
}
