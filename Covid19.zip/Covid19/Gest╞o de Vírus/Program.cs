﻿using System;
using System.ComponentModel.Design;

namespace Gestão_de_Vírus
{
    class Program
    {
        static void Main(string[] args)
        {
            //int opcao = 0;
            //Paciente paciente = new Paciente();

            //Console.WriteLine("Quantos pacientes pretende inserir");
            //opcao = int.Parse(Console.ReadLine());

            //for (int i = 0; i < opcao; i++)
            //{
            //    paciente = Paciente.InserirP();
            //    Paciente.InserePaciente(p);

            //}
            
        }

        public int Menu()
        {
            int opcao = 0;

            Console.WriteLine("[1] Inserir / Criar pacientes");
            Console.WriteLine("[2] Editar pacientes");
            Console.WriteLine("[3] Remover pacientes");
            Console.WriteLine("[4] Listar pacientes");

            Console.WriteLine("[1] Inserir / Criar medico");
            Console.WriteLine("[2] Editar medico");
            Console.WriteLine("[3] Remover medico");
            Console.WriteLine("[4] Listar medico");
            return opcao;
        }
    }
}
