﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gestão_de_Vírus
{
    class Hospital
    {
        #region ATRIBUTOS
        Residencia localidade;
        int numEquipamentos;
        Medico[] medico;
        #endregion

        #region PROPRIEDADES
        public int NumEquipamentos
        {
            get { return numEquipamentos; }
            set { numEquipamentos = value; }
        }

        public Residencia Localidade
        {
            get { return localidade; }
            set { localidade = value; }
        }
        #endregion
    }
}
