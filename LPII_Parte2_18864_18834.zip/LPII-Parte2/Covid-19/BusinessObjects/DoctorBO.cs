﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObjects
{
    public enum Specialty
    {
        NEUROLOGY = 1,
        CARDIOLOGY = 2,
        PEDIATRICS = 3,
        SURGERY = 4,
        OBSTETRICS = 5,
        ORTHOPEDICS = 6
    }
    public class DoctorBO : PersonBO
    {
        #region ATRIBUTES

        private string work;
        private int codeDoctor;

        #endregion

        #region CONSTRUCTORS

        //empty constructor
        public DoctorBO()
        {

        }

        #endregion

        #region PROPERTIES

        /// <summary>
        /// Handle work attribute
        /// </summary>
        public string Work
        { 
            get => work;
        }

        public Specialty SpecialtyWork
        {
            set
            {
                if (value == Specialty.CARDIOLOGY)
                {
                    work = "Cardiology";
                }
                else if (value == Specialty.NEUROLOGY)
                {
                    work = "Neurology";
                }
                else if (value == Specialty.OBSTETRICS)
                {
                    work = "Obstetrics";
                }
                else if (value == Specialty.ORTHOPEDICS)
                {
                    work = "Orthopedics";
                }
                else if (value == Specialty.PEDIATRICS)
                {
                    work = "Pediatrics";
                }
                else if (value == Specialty.SURGERY)
                {
                    work = "Surgery";
                }
            }
        }

        /// <summary>
        /// Handle code doctor attribute
        /// </summary>
        public int CodeDoctor
        {
            get => codeDoctor;
            set => codeDoctor = value;
        }
        #endregion

        #region OVERRIDE
        /// <summary>
        /// List doctor
        /// </summary>
        public override string ToString()
        {
            return "\n\tName: " + Name + "\n\tAge: " + Age + "\n\tBirthday: " + Birthday.ToShortDateString() + "\n\tGender: " + Gender + "\n\tResidence: " + 
                Residence + "\n\tSpecialty: " + Work + "\n\tCode: " + CodePerson + "-" + CodeDoctor;
        }
        #endregion
    }
}
