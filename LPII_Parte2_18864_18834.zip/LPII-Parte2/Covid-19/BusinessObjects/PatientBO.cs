﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObjects
{
    public enum Status
    {
        CURED = 1,
        INFECTED = 2,
        SUSPECTED = 3,
        DEAD = 4
    }

    public class PatientBO : PersonBO
    {
        #region ATRIBUTES

        private string situacion;
        DateTime entryHospital;
        private int codePatient;

        #endregion

        #region CONSTRUCTORS

        //empty constructor
        public PatientBO()
        {

        }

        #endregion

        #region PROPERTIES

        /// <summary>
        /// Handle situacion attribute
        /// </summary>
        public string Situacion
        { 
            get => situacion; 
        }

        /// <summary>
        /// Handle data of entry in hospital attribute
        /// </summary>
        public DateTime EntryHospital 
        {
            get => entryHospital;
            set => entryHospital = value; 
        }

        public Status StatusSituacion
        {
            set
            {
                if (value == Status.CURED)
                {
                    situacion = "Cured";
                }
                else if (value == Status.DEAD)
                {
                    situacion = "Dead";
                }
                else if (value == Status.INFECTED)
                {
                    situacion = "Infected";
                }
                else if (value == Status.SUSPECTED)
                {
                    situacion = "Suspected";
                }
            }
        }

        /// <summary>
        /// Handle code patient attribute
        /// </summary>
        public int CodePatient
        {
            get => codePatient;
            set => codePatient = value;
        }

        #endregion

        #region OVERRIDE
        /// <summary>
        /// List persons
        /// </summary>
        public override string ToString()
        {
            return "\n\tName: " + Name + "\n\tAge: " + Age + "\n\tBirthday: " + Birthday.ToShortDateString() + "\n\tGender: " + Gender + "\n\tResidence: " + Residence + "\n\tSituacion: " + Situacion + "\n\tEntry Hospital: " + EntryHospital.ToShortDateString() + "\n\tCode: " + CodePerson + "-" + CodePatient;
        }
        #endregion
    }
}
