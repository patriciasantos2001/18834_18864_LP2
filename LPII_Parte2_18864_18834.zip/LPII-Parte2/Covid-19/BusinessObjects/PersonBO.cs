﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessObjects
{
    public enum Sex
    {
        FEMALE = 1,
        MALE = 2
    }

    public enum Home
    {
        ACORES = 1,
        ALGARVE = 2,
        LISBOA = 3,
        MADEIRA = 4,
        PORTO = 5
    }

    public class PersonBO
    {
        #region ATTRIBUTES

        private string name;
        private DateTime birthday;
        private int age;
        private string gender;
        private string residence;
        private int codePerson;

        #endregion

        #region CONSTRUCTORS

        //empty contructor
        public PersonBO()
        {
            
        }
    

        #endregion

        #region PROPERTIES
        //Methods used to manipulate state attributes

        /// <summary>
        /// Handle name attribute
        /// </summary>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        /// <summary>
        /// Handle birthday attribute
        /// </summary>
        public DateTime Birthday
        {
            get { return birthday; }
            set 
            { 
                birthday = value;

                AssignAge();
            }
        }

        /// <summary>
        /// Handle Age attribute
        /// </summary>
        public int Age
        {
            get => age;
        }

        /// <summary>
        /// Handle Gender attribute
        /// </summary>
        public string Gender
        {
            get => gender;
        }

        /// <summary>
        /// Handle Residence Attribute
        /// </summary>
        public string Residence
        {
            get => residence;
        }

        public Sex GenderSituacion
        {
            set
            {
                if (value == Sex.FEMALE)
                {
                    gender = "Female";
                }
                else if (value == Sex.MALE)
                {
                    gender = "Male";
                }
            }
        }

        public Home ResidenceSituacion
        {
            set
            {
                if (value == Home.ACORES)
                {
                    residence = "Açores";
                }
                else if (value == Home.ALGARVE)
                {
                    residence = "Algarve";
                }
                else if (value == Home.LISBOA)
                {
                    residence = "Lisboa";
                }
                else if (value == Home.MADEIRA)
                {
                    residence = "Madeira";
                }
                else if (value == Home.PORTO)
                {
                    residence = "Porto";
                }
            }
        }
       
        /// <summary>
        /// Handle Code person attribute
        /// </summary>
        public int CodePerson
        {
            get => codePerson;
            set => codePerson = value;
        }
        #endregion

        #region METHODS
        /// <summary>
        /// Assign Age 
        /// </summary>
        /// <param name="birthday">Birthday</param>
        /// <returns></returns>
        private void AssignAge()
        {
            int currentYear;
            int birthdayYear;

            if (int.TryParse(DateTime.Today.Year.ToString(), out currentYear))
            {
                if (int.TryParse(birthday.Year.ToString(), out birthdayYear))
                {
                    if (birthday.Month == DateTime.Today.Month)
                    {
                        if (birthday.Day < DateTime.Today.Day)
                        {
                            currentYear -= 1;

                        }
                    }
                    else if (birthday.Month > birthday.Day)
                    {
                        currentYear -= 1;
                    }
                    age = currentYear - birthdayYear;
                }
            }
        }


        #endregion

        #region OVERRIDE
        /// <summary>
        /// List persons
        /// </summary>
        public override string ToString()
        {
            Console.WriteLine("\nPerson {0}:\n");
            return string.Format("\n\tName: {0}\n\tAge: {1}\n\tBirthday: {2}\n\tGender: {3}\n\tResidence: {4}\n",
                                 Name, Age, Birthday.ToShortDateString(), Residence);
        }
        #endregion
    }
}
