﻿using System;
using BusinessObjects;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Data
{
    public class Codes
    {
        private static List<int> codePeople;
        private static List<int> codeDoctors;
        private static List<int> codePatients;

        static Codes()
        {
            codePeople = new List<int>();
            codeDoctors = new List<int>();
            codePatients = new List<int>();
        }

        #region METHODS

        public static bool VerifyCodePerson(int codePerson)
        {
            if (codePeople.Contains(codePerson))    //Exist?
                return true;
            return false;
        }

        public static bool VerifyCodeDoctor(int codeDoctor)
        {
            if (codePeople.Contains(codeDoctor))    //Exist?
                return true;
            return false;
        }

        public static bool VerifyCodePatient(int codePatient)
        {
            if (codePeople.Contains(codePatient))    //Exist?
                return true;
            return false;
        }

        /// <summary>
        /// Add code
        /// </summary>
        /// <param name="pt"></param>
        /// <returns></returns>
        public static void AddPersonCode(int codePerson)
        {
            codePeople.Add(codePerson);
        }

        public static void AddDoctorCode(int codeDoctor)
        {
              codeDoctors.Add(codeDoctor);
        }

        public static void AddPatientCode(int codePatient)
        {
            codePatients.Add(codePatient);
        }
        #endregion
    }
}

