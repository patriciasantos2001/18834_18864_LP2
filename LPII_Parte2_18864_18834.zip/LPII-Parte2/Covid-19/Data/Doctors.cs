﻿using System;
using BusinessObjects;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess
{
    public class Doctors
    {
        private static List<DoctorBO> doctor;

        static Doctors()
        {
            doctor = new List<DoctorBO>();
        }

        public static List<DoctorBO> ShowDoctor()
        {
            return doctor;
        }

        #region METHODS

        /// <summary>
        /// Add doctor
        /// </summary>
        /// <param name="d"></param>
        /// <returns></returns>
        public static bool AddDoctor(DoctorBO d)
        {
            if (doctor.Contains(d)) return false;
            doctor.Add(d);
            return true;
        }

        public static bool UpdateDoctor(int index, DoctorBO d)
        {
            doctor.Insert(index, d);
            return true;
        }
        #endregion

    }
}
