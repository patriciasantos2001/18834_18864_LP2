﻿using System;
using BusinessObjects;
using System.Collections.Generic;
using System.Text;
using Data;

namespace DataAccess
{
    public class Persons
    {
        private static List<PersonBO> person;

        static Persons()
        {
            person = new List<PersonBO>();
        }

        #region OVERRIDE

        #endregion

        #region METHODS

        /// <summary>
        /// Insert new person
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        public static bool AddPerson(PersonBO p)
        {
            if (person.Contains(p)) return false;
            person.Add(p);
            return true;
        }

        public static bool UpdatePerson(int index, PersonBO p)
        {
            person.Insert(index, p);
            return true;
        }
        #endregion
    }
}
