﻿using BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess
{
    public class Patients
    {
        private static List<PatientBO> patient;

        static Patients()
        {
            patient = new List<PatientBO>();
        }

        #region OVERRIDE

        #endregion

        #region METHODS

        public static List<PatientBO> ShowPatient()
        {
            return patient;
        }

        /// <summary>
        /// Add patient
        /// </summary>
        /// <param name="pt"></param>
        /// <returns></returns>
        public static bool AddPatient(PatientBO pt)
        {
            if (patient.Contains(pt)) return false;
            patient.Add(pt);
            return true;
        }

        public static bool UpdatePatient(int index, PatientBO pt)
        {
            patient.Insert(index, pt);
            return true;
        }
        #endregion
    }
}