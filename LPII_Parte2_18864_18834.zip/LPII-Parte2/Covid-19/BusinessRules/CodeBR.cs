﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Data;
using DataAccess;

namespace BusinessRules
{
    class CodeBR
    {
        public CodeBR() { }

        public static bool VerifyCodePerson(int codePerson)
        {
            return Codes.VerifyCodePerson(codePerson);
        }

        public static bool VerifyCodePatient(int codePatient)
        {
            return Codes.VerifyCodePatient(codePatient);
        }

        public static bool VerifyCodeDoctor(int codeDoctor)
        {
            return Codes.VerifyCodeDoctor(codeDoctor);
        }
    }
}
