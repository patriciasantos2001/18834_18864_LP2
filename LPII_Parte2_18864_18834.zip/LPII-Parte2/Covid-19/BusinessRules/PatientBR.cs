﻿using System;
using DataAccess;
using BusinessObjects;
using Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessRules
{
    public class PatientBR
    {
        public PatientBR()
        {
        }

        public static List<PatientBO> ShowPatients()
        {
            return Patients.ShowPatient();
        }

        protected static PatientBO GenerateCodePatient(PatientBO pt)
        {
            PersonBO p = PersonBR.GenerateCodePerson(pt);
            pt.CodePerson = p.CodePerson;
            int codePatient;
            do
            {
            codePatient = new Random().Next(1000, 9999);
            } while (CodeBR.VerifyCodePatient(codePatient));
            pt.CodePatient = codePatient;
            return pt;
        }

        public static bool InsertPatient(PatientBO pt)
        {
            pt = GenerateCodePatient(pt);
            
            if (Patients.AddPatient(pt))   //If Person Add?
            {
                Codes.AddPatientCode(pt.CodePatient);
                Codes.AddPersonCode(pt.CodePerson);
                return true;
            }
            return false;
        }

        public static bool UpdatePatient(int index, PatientBO pt)
        {
            return Patients.UpdatePatient(index, pt);
        }

    }
}
