﻿using System;
using DataAccess;
using BusinessObjects;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Data;

namespace BusinessRules
{
    public class PersonBR
    {
        public PersonBR()
        {

        }

        public static PersonBO GenerateCodePerson(PersonBO p)
        {
            int codePerson;
            do
            {
                codePerson = new Random().Next(1111, 9999);
            } while (CodeBR.VerifyCodePerson(codePerson));
            p.CodePerson = codePerson;
            return p;
        }

        public static bool InsertPerson(PersonBO p)
        {
            p = GenerateCodePerson(p);
            if (Persons.AddPerson(p))   //If Person Add?
            {
                Codes.AddPersonCode(p.CodePerson);
                return true;
            }
            return false;
        }

        public static bool UpdatePerson(int index, PersonBO p)
        {
            return Persons.UpdatePerson(index, p);
        }

    }
}
