﻿using System;
using DataAccess;
using BusinessObjects;
using Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessRules
{
    public class DoctorBR
    {
        public DoctorBR()
        {
        }

        protected static DoctorBO GenerateCodeDoctor(DoctorBO d)
        {
            int codeDoctor;

            PersonBO p = PersonBR.GenerateCodePerson(d);
            d.CodePerson = p.CodePerson;

            do
            {
                codeDoctor = new Random().Next(1000, 9999);
            } while (CodeBR.VerifyCodeDoctor(codeDoctor));
            d.CodeDoctor = codeDoctor;
            return d;
        }

        public static bool InsertDoctor(DoctorBO d)
        {
            d = GenerateCodeDoctor(d);
            if (Doctors.AddDoctor(d))   //If Person Add?
            {
                Codes.AddDoctorCode(d.CodeDoctor);
                return true;
            }
            return false;
        }

        public static List<DoctorBO> ShowDoctor()
        {
            return Doctors.ShowDoctor();
        }
        public static bool UpdateDoctor(int index, DoctorBO d)
        {
            return Doctors.UpdateDoctor(index, d);
        }

    }
}
