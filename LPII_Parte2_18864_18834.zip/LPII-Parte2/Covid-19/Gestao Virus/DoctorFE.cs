﻿using System;
using BusinessObjects;
using System.Collections.Generic;
using System.Text;

namespace Gestao_Virus
{
    public class DoctorFE
    {
        #region METHODS
        public static DoctorBO DoctorData(DoctorBO d)
        {
            d = new DoctorBO();
            PersonFE.PersonData(d);

            d = AssignWork(d);

            return d;
        }

        public static DoctorBO AssignWork(DoctorBO d)
        {
            ConsoleKeyInfo workKey;

            do
            {
                Console.WriteLine("Insert work Specialty:");
                Console.WriteLine("[1] Neurology \n[2] Cardiology \n[3] Pediatrics \n[4] Surgery \n[5] Obstetrics \n[6] Orthopedics \t");
                workKey = Console.ReadKey();

                switch (workKey.Key)
                {
                    case ConsoleKey.D1:
                        d.SpecialtyWork = Specialty.NEUROLOGY;
                        break;
                    case ConsoleKey.D2:
                        d.SpecialtyWork = Specialty.CARDIOLOGY;
                        break;
                    case ConsoleKey.D3:
                        d.SpecialtyWork = Specialty.PEDIATRICS;
                        break;
                    case ConsoleKey.D4:
                        d.SpecialtyWork = Specialty.SURGERY;
                        break;
                    case ConsoleKey.D5:
                        d.SpecialtyWork = Specialty.OBSTETRICS;
                        break;
                    case ConsoleKey.D6:
                        d.SpecialtyWork = Specialty.ORTHOPEDICS;
                        break;
                    default:
                        Console.WriteLine("\nInvalid Value!\n");
                        break;
                }
            } while (workKey.Key != ConsoleKey.D1 && workKey.Key != ConsoleKey.D2 && workKey.Key != ConsoleKey.D3 && workKey.Key != ConsoleKey.D4 && workKey.Key != ConsoleKey.D5 && workKey.Key != ConsoleKey.D6 && workKey.Key != ConsoleKey.D7);
            return d;
        }
        public static string InsertDoctor()
        {
            string specialty = "";
            ConsoleKeyInfo workKey;

            do
            {
                Console.WriteLine("Insert work Specialty:");
                Console.WriteLine("[1] Neurology \n[2] Cardiology \n[3] Pediatrics \n[4] Surgery \n[5] Obstetrics \n[6] Orthopedics \t");
                workKey = Console.ReadKey();

                switch (workKey.Key)
                {
                    case ConsoleKey.D1:
                        specialty = "Neurology";
                        break;
                    case ConsoleKey.D2:
                        specialty = "Cardiology";
                        break;
                    case ConsoleKey.D3:
                        specialty = "Pediatrics";
                        break;
                    case ConsoleKey.D4:
                        specialty = "Surgery";
                        break;
                    case ConsoleKey.D5:
                        specialty = "Obstetrics";
                        break;
                    case ConsoleKey.D6:
                        specialty = "Orthopedics";
                        break;
                    default:
                        Console.WriteLine("\nInvalid Value!\n");
                        break;
                }
            } while (workKey.Key != ConsoleKey.D1 && workKey.Key != ConsoleKey.D2 && workKey.Key != ConsoleKey.D3 && workKey.Key != ConsoleKey.D4 && workKey.Key != ConsoleKey.D5 && workKey.Key != ConsoleKey.D6 && workKey.Key != ConsoleKey.D7);
            return specialty;
        }
        #endregion
    }
}
