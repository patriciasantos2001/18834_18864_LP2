﻿using System;
using BusinessObjects;
using BusinessRules;
using System.Collections.Generic;
using System.Text;

namespace Gestao_Virus
{
    public class PatientFE
    {
        #region METHODS
        /// <summary>
        /// Ask for person data
        /// </summary>
        /// <param name=""></param>
        public static PatientBO PatientData(PatientBO pt)
        {
            Boolean auxEntry;
            DateTime e;
            pt = new PatientBO();

            PersonFE.PersonData(pt);

            //ask for 
            pt = AssignSituacion(pt);

            //Entry at Hospital
            do
            {
                Console.WriteLine("\n\nEntry at Hospital:");
                auxEntry = DateTime.TryParse(Console.ReadLine(), out e);

                //if auxDate == true, change DateTime e to pt.EntryHospital
                if (auxEntry == true)
                {
                    pt.EntryHospital = e;
                    //break to end the cycle
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid Date!");
                }
            } while (auxEntry != true);

            return pt;
        }

        public static PatientBO AssignSituacion(PatientBO pt)
        {
            ConsoleKeyInfo situacionKey;

            do
            {
                Console.WriteLine("\n\nInsert Situacion:");
                Console.WriteLine("[1] Cured \n[2] Infected \n[3] Suspect \n[4] Dead\t");
                situacionKey = Console.ReadKey();

                switch (situacionKey.Key)
                {
                    case ConsoleKey.D1:
                        pt.StatusSituacion = Status.CURED;
                        break;
                    case ConsoleKey.D2:
                        pt.StatusSituacion = Status.INFECTED;
                        break;
                    case ConsoleKey.D3:
                        pt.StatusSituacion = Status.SUSPECTED;
                        break;
                    case ConsoleKey.D4:
                        pt.StatusSituacion = Status.DEAD;
                        break;
                    default:
                        Console.WriteLine("\nInvalid Value!\n");
                        break;
                }
            } while (situacionKey.Key != ConsoleKey.D1 && situacionKey.Key != ConsoleKey.D2 && situacionKey.Key != ConsoleKey.D3 && situacionKey.Key != ConsoleKey.D4);
            return pt;
        }
        #endregion

    }
}
