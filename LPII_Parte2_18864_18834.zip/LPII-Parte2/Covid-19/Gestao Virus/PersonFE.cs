﻿using System;
using BusinessObjects;
using BusinessRules;
using System.Collections.Generic;
using System.Text;

namespace Gestao_Virus
{
    public class PersonFE
    {
        #region METHODS

        /// <summary>
        /// Ask for person data
        /// </summary>
        /// <param name=""></param>
        public static void PersonData(PersonBO p)
        {
            Boolean auxDate;
            DateTime b;

            //Ask Name
            Console.WriteLine("Insert Name:");
            p.Name = Console.ReadLine();

            //Ask Birthday
            do
            {
                //Insert birthday again
                Console.WriteLine("\nInsert Birthday:");
                auxDate = DateTime.TryParse(Console.ReadLine(), out b);

                //if auxDate == true, change DateTime b to p.Birthday
                if(auxDate == true)
                {
                    p.Birthday = b;
                    //break to end the cycle
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid Date!");
                }

            } while (auxDate != true);

            //Insert Gender
            p = AssignGender(p);

            //Insert Residence
            p = AssignResidence(p);
        }

        /// <summary>
        /// Insert Gender automatticaly
        /// </summary>
        /// <param name=""></param>
        public static PersonBO AssignGender(PersonBO p)
        {
            ConsoleKeyInfo genderKey;

            do
            {
                Console.WriteLine("\nInsert Gender:");
                Console.WriteLine("[1] Female \n[2] Male");
                genderKey = Console.ReadKey();

                switch (genderKey.Key)
                {
                    case ConsoleKey.D1:
                        p.GenderSituacion = Sex.FEMALE;
                        break;
                    case ConsoleKey.D2:
                        p.GenderSituacion = Sex.MALE;
                        break;
                    default:
                        Console.WriteLine("\nInvalid Value!\n");
                        break;
                }
            } while (genderKey.Key != ConsoleKey.D1 && genderKey.Key != ConsoleKey.D2);
            return p;
        }

        public static string InsertGender()
        {
            string gender = "";
            ConsoleKeyInfo genderKey;

            do
            {
                Console.WriteLine("\nInsert Gender:");
                Console.WriteLine("[1] Female \n[2] Male");
                genderKey = Console.ReadKey();

                switch (genderKey.Key)
                {
                    case ConsoleKey.D1:
                        gender = "Female";
                        break;
                    case ConsoleKey.D2:
                        gender = "Male";
                        break;
                    default:
                        Console.WriteLine("\nInvalid Value!\n");
                        break;
                }
            } while (genderKey.Key != ConsoleKey.D1 && genderKey.Key != ConsoleKey.D2);
            return gender;
        }

        /// <summary>
        /// Insert Gender automatticaly
        /// </summary>
        /// <param name=""></param>
        public static PersonBO AssignResidence(PersonBO p)
        {
            ConsoleKeyInfo residenceKey;

            do
            {
                Console.WriteLine("\n\nInsert residence of patient");
                Console.WriteLine("[1] Açores \n[2] Algarve \n[3] Lisboa \n[4] Madeira \n[5] Porto");
                residenceKey = Console.ReadKey();

                switch (residenceKey.Key)
                {
                    case ConsoleKey.D1:
                        p.ResidenceSituacion = Home.ACORES;
                        break;
                    case ConsoleKey.D2:
                        p.ResidenceSituacion = Home.ALGARVE;
                        break;
                    case ConsoleKey.D3:
                        p.ResidenceSituacion = Home.LISBOA;
                        break;
                    case ConsoleKey.D4:
                        p.ResidenceSituacion = Home.MADEIRA;
                        break;
                    case ConsoleKey.D5:
                        p.ResidenceSituacion = Home.PORTO;
                        break;
                    default:
                        Console.WriteLine("\nInvalid Value!");
                        break;
                }
            } while (residenceKey.Key != ConsoleKey.D1 && residenceKey.Key != ConsoleKey.D2 && residenceKey.Key != ConsoleKey.D3 && residenceKey.Key != ConsoleKey.D4 && residenceKey.Key != ConsoleKey.D5);
            return p;
        }

        public static string InsertResidence()
        {
            string residence = "";
            ConsoleKeyInfo residenceKey;

            do
            {
                Console.WriteLine("\nInsert residence of patient");
                Console.WriteLine("[1] Açores \n[2] Algarve \n[3] Lisboa \n[4] Madeira \n[5] Porto");
                residenceKey = Console.ReadKey();

                switch (residenceKey.Key)
                {
                    case ConsoleKey.D1:
                        residence = "Açores";
                        break;
                    case ConsoleKey.D2:
                        residence = "Algarve";
                        break;
                    case ConsoleKey.D3:
                        residence = "Lisboa";
                        break;
                    case ConsoleKey.D4:
                        residence = "Madeira";
                        break;
                    case ConsoleKey.D5:
                        residence = "Porto";
                        break;
                    default:
                        Console.WriteLine("\nInvalid Value!");
                        break;
                }
            } while (residenceKey.Key != ConsoleKey.D1 && residenceKey.Key != ConsoleKey.D2 && residenceKey.Key != ConsoleKey.D3 && residenceKey.Key != ConsoleKey.D4 && residenceKey.Key != ConsoleKey.D5);
            return residence;
        }

    }
    #endregion
}
