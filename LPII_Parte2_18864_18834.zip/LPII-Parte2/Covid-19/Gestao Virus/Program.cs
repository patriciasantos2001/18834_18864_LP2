﻿using System;
using BusinessObjects;
using BusinessRules;
using System.Collections;
using System.Collections.Generic;
using System.Net.NetworkInformation;

namespace Gestao_Virus
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            //Console.Clear();

            PersonBO p = new PersonBO();
            PatientBO pt = new PatientBO();
            DoctorBO d = new DoctorBO();
            List<PatientBO> listPatients = new List<PatientBO>();
            List<DoctorBO> listDoctor = new List<DoctorBO>();

            Menu(pt, listPatients, d, listDoctor);
        }

        #region MENU
        public static void Menu(PatientBO pt, List<PatientBO> listPatients, DoctorBO d, List<DoctorBO> listDoctor)
        {
            ConsoleKeyInfo number;

            Console.Clear();

            Console.WriteLine("\t**********************");
            Console.WriteLine("\t*  Insert an option  *");
            Console.WriteLine("\t**********************");
            Console.WriteLine("\t*   [1]  Person      *");
            Console.WriteLine("\t*   [2]  Disease     *");
            Console.WriteLine("\t**********************");

            number = Console.ReadKey();

            Console.Clear();

            switch (number.Key)
            {
                case ConsoleKey.D1:
                    MenuPerson(pt, listPatients, d, listDoctor);
                    break;

                case ConsoleKey.D2:
                    MenuDisease();
                    break;

                default:
                    break;
            }

        }

        public static void MenuPerson(PatientBO pt, List<PatientBO> listPatients, DoctorBO d, List<DoctorBO> listDoctor)
        {
            ConsoleKeyInfo number;

            Console.Clear();

            Console.WriteLine("\t**********************");
            Console.WriteLine("\t*  Insert an option  *");
            Console.WriteLine("\t**********************");
            Console.WriteLine("\t*   [1]  Patient     *");
            Console.WriteLine("\t*   [2]  Doctor      *");
            Console.WriteLine("\t**********************");

            number = Console.ReadKey();

            Console.Clear();

            switch (number.Key)
            {
                case ConsoleKey.D1:
                    MenuPatient(pt, listPatients);
                    break;

                case ConsoleKey.D2:
                    MenuDoctor(d, listDoctor);
                    break;

                default:
                    break;
            }

        }

        #region MENU_PATIENT
        public static void MenuPatient(PatientBO pt, List<PatientBO> listPatients)
        {
            ConsoleKeyInfo number;
            int option = 0;
            bool aux;
            int code = 0;

            do
            {
                Console.Clear();

                Console.WriteLine("\t***********************************");
                Console.WriteLine("\t*         Insert an option        *");
                Console.WriteLine("\t***********************************");
                Console.WriteLine("\t*   [1]  Insert Patient           *");
                Console.WriteLine("\t*   [2]  List Patients            *");
                Console.WriteLine("\t*   [3]  Edit Patient             *");
                Console.WriteLine("\t*   [4]  Search Patient Register  *");
                Console.WriteLine("\t*   [5]  Infected                 *");
                Console.WriteLine("\t*   [6]  Suspected                *");
                Console.WriteLine("\t*   [7]  Cured                    *");
                Console.WriteLine("\t*   [8]  Dead                     *");
                Console.WriteLine("\t***********************************");

                number = Console.ReadKey();

                Console.Clear();

                switch (number.Key)
                {
                    case ConsoleKey.D1:
                        Console.WriteLine("How many patients do you want to insert?");
                        option = int.Parse(Console.ReadLine());

                        for (int i = 0; i < option; i++)
                        {
                            Console.WriteLine("\nPatient {0}:\n", i + 1);
                            pt = PatientFE.PatientData(pt);
                            aux = PatientBR.InsertPatient(pt);

                            if (aux == true)
                            {
                                //listar dados
                                Console.WriteLine("\nSucessfully Inserted!\n");
                            }
                            else
                            {
                                Console.WriteLine("\nUnsucessfully Inserted!\n");
                            }
                        }
                        break;

                    case ConsoleKey.D2:
                        MenuList(pt, listPatients);
                        break;

                    case ConsoleKey.D3:
                        MenuEdit(pt, listPatients);
                        break;

                    case ConsoleKey.D4:
                        Console.WriteLine("Insert first four numbers from patient code that you want to change.\n");
                        code = int.Parse(Console.ReadLine());

                        listPatients = PatientBR.ShowPatients();
                        if (listPatients.Count == 0)
                        {
                            Console.WriteLine("There are not patients on the list!");
                            Console.ReadKey();
                            break;
                        }

                        for (int i = 0; i < listPatients.Count; i++)
                        {
                            if (code == listPatients[i].CodePerson)
                            {
                                Console.Clear();
                                Console.WriteLine("*****************************************");
                                Console.WriteLine("*            Patient Info               *");
                                Console.WriteLine("*****************************************");
                                Console.WriteLine(listPatients[i].ToString());
                                Console.WriteLine("\n***************************************");
                            }
                            else
                            {
                                Console.WriteLine("Invalid Code!");
                            }
                        }
                        Console.ReadKey();
                        break;

                    case ConsoleKey.D5:
                        MenuInfected(pt, listPatients);
                        break;

                    case ConsoleKey.D6:
                        MenuSuspected(pt, listPatients);
                        break;

                    case ConsoleKey.D7:
                        MenuCured(pt, listPatients);
                        break;

                    case ConsoleKey.D8:
                        MenuDead(pt, listPatients);
                        break;

                    default:
                        break;
                }
            } while (number.Key != ConsoleKey.D0);
            
        }

        #region MENU_EDIT
        public static void MenuEdit(PatientBO pt, List<PatientBO> listPatients)
        {
            ConsoleKeyInfo number;
            int code;

            Console.Clear();

            Console.WriteLine("\t*******************************");
            Console.WriteLine("\t*       Insert an option      *");
            Console.WriteLine("\t*******************************");
            Console.WriteLine("\t*   [1]  Edit Condition       *");
            Console.WriteLine("\t*   [2]  Edit Residence       *");
            Console.WriteLine("\t*   [3]  Edit Gender          *");
            Console.WriteLine("\t*******************************");

            number = Console.ReadKey();

            Console.Clear();

            listPatients = PatientBR.ShowPatients();

            switch (number.Key)
            {
                case ConsoleKey.D1:
                    Console.WriteLine("Insert first four numbers from patient code that you want to change.\n");
                    code = int.Parse(Console.ReadLine());

                    for (int i = 0; i < listPatients.Count; i++)
                    {
                        if (code == listPatients[i].CodePerson)
                        {
                            if (PersonBR.UpdatePerson(i, PatientFE.AssignSituacion(listPatients[i])))
                            {
                                Console.WriteLine("Update Successful!");
                            }
                            else
                            {
                                Console.WriteLine("Update Unsuccessful!");
                            }
                            break;
                        }
                    }
                    Console.ReadKey();
                    break;

                case ConsoleKey.D2:
                    Console.WriteLine("Insert first four numbers from patient code that you want to change.\n");
                    code = int.Parse(Console.ReadLine());

                    for (int i = 0; i < listPatients.Count; i++)
                    {
                        if (code == listPatients[i].CodePerson)
                        {
                            if (PersonBR.UpdatePerson(i, PersonFE.AssignResidence(listPatients[i])))
                            {
                                Console.WriteLine("Update Successful!");
                            }
                            else
                            {
                                Console.WriteLine("Update Unsuccessful!");
                            }
                            break;
                        }
                    }
                    Console.ReadKey();
                    break;

                case ConsoleKey.D3:
                    Console.WriteLine("Insert first four numbers from patient code that you want to change.\n");
                    code = int.Parse(Console.ReadLine());

                    for (int i = 0; i < listPatients.Count; i++)
                    {
                        if (code == listPatients[i].CodePerson)
                        {
                            if (PersonBR.UpdatePerson(i, PersonFE.AssignGender(listPatients[i])))
                            {
                                Console.WriteLine("Update Successful!");
                            }
                            else
                            {
                                Console.WriteLine("Update Unsuccessful!");
                            }
                            break;
                        }
                    }
                    Console.ReadKey();
                    break;
                default:
                    break;
            }

        }
        #endregion

        #region MENU_LIST
        public static void MenuList(PatientBO pt, List<PatientBO> listPatients)
        {
            ConsoleKeyInfo number;
            string residence;
            string gender;
            int age;

            Console.Clear();

            Console.WriteLine("\t*******************************");
            Console.WriteLine("\t*       Insert an option      *");
            Console.WriteLine("\t*******************************");
            Console.WriteLine("\t*   [1]  List All             *");
            Console.WriteLine("\t*   [2]  List by Residence    *");
            Console.WriteLine("\t*   [3]  List by Gender       *");
            Console.WriteLine("\t*   [4]  List by Age          *");
            Console.WriteLine("\t*******************************");

            number = Console.ReadKey();

            Console.Clear();

            switch (number.Key)
            {
                case ConsoleKey.D1:
                    listPatients = PatientBR.ShowPatients();

                    Console.WriteLine("*****************************************");
                    Console.WriteLine("*            Patient Info               *");

                    for (int i = 0; i < listPatients.Count; i++)
                    {
                        Console.WriteLine("*****************************************");
                        Console.WriteLine(listPatients[i].ToString());
                        Console.WriteLine("\n***************************************");
                    }
                    Console.ReadKey();
                    break;

                case ConsoleKey.D2:
                    listPatients = PatientBR.ShowPatients();

                    residence = PersonFE.InsertResidence();

                    if (listPatients.Count == 0)
                    {
                        Console.WriteLine("There are not patients on the list with that residence!");
                        Console.ReadKey();
                        break;
                    }

                    for (int i = 0; i < listPatients.Count; i++)
                    {
                        if (residence == listPatients[i].Residence)
                        {
                            Console.Clear();
                            Console.WriteLine("*****************************************");
                            Console.WriteLine("*            Patient Info               *");
                            Console.WriteLine("*****************************************");
                            Console.WriteLine(listPatients[i].ToString());
                            Console.WriteLine("\n***************************************");
                        }
                        else 
                        {
                            Console.WriteLine("\nInvalid Residence!");
                        }
                    }
                    Console.ReadKey();
                    break;

                case ConsoleKey.D3:
                    listPatients = PatientBR.ShowPatients();

                    gender = PersonFE.InsertGender();

                    if (listPatients.Count == 0)
                    {
                        Console.WriteLine("\nThere are not patients on the list with that gender!");
                        Console.ReadKey();
                        break;
                    }

                    for (int i = 0; i < listPatients.Count; i++)
                    {
                        if (gender == listPatients[i].Gender)
                        {
                            Console.Clear();
                            Console.WriteLine("*****************************************");
                            Console.WriteLine("*            Patient Info               *");
                            Console.WriteLine("*****************************************");
                            Console.WriteLine(listPatients[i].ToString());
                            Console.WriteLine("\n***************************************");
                        }
                        else 
                        {
                            Console.WriteLine("\nInvalid Gender!");
                        }
                    }
                    Console.ReadKey();
                    break;

                case ConsoleKey.D4:
                    listPatients = PatientBR.ShowPatients();

                    Console.WriteLine("Insert age of person that you want so search.\n");
                    age = int.Parse(Console.ReadLine());

                    if (listPatients.Count == 0)
                    {
                        Console.WriteLine("There are not patients on the list with that age!");
                        Console.ReadKey();
                        break;
                    }

                    for (int i = 0; i < listPatients.Count; i++)
                    {
                        if (age == listPatients[i].Age)
                        {
                            Console.Clear();
                            Console.WriteLine("*****************************************");
                            Console.WriteLine("*            Patient Info               *");
                            Console.WriteLine("*****************************************");
                            Console.WriteLine(listPatients[i].ToString());
                            Console.WriteLine("\n***************************************");
                        }
                        else 
                        {
                            Console.WriteLine("\nInvalid Age!");
                        }
                    }
                    Console.ReadKey();
                    break;

                default:
                    break;
            }

        }
        #endregion

        #region MENU_SITUACION
        public static void MenuInfected(PatientBO pt, List<PatientBO> listPatients)
        {
            ConsoleKeyInfo number;
            string residence;
            string gender;
            int age;
            int count = 0;

            Console.Clear();

            Console.WriteLine("\t*******************************");
            Console.WriteLine("\t*       Insert an option      *");
            Console.WriteLine("\t*******************************");
            Console.WriteLine("\t*   [1]  List All             *");
            Console.WriteLine("\t*   [2]  List by Residence    *");
            Console.WriteLine("\t*   [3]  List by Gender       *");
            Console.WriteLine("\t*   [4]  List by Age          *");
            Console.WriteLine("\t*******************************");

            number = Console.ReadKey();

            Console.Clear();

            switch (number.Key)
            {
                case ConsoleKey.D1:
                    listPatients = PatientBR.ShowPatients();

                    for (int i = 0; i < listPatients.Count; i++)
                    {
                        if (listPatients[i].Situacion == "Infected")
                        {
                            Console.WriteLine(listPatients[i].ToString());
                        }
                    }
                    Console.ReadKey();
                    break;

                case ConsoleKey.D2:
                    Console.WriteLine("Infected:");

                    listPatients = PatientBR.ShowPatients();

                    residence = PersonFE.InsertResidence();

                    if (listPatients.Count == 0)
                    {
                        Console.WriteLine("There are not patients on the list with that residence!");
                        Console.ReadKey();
                        break;
                    }

                    for (int i = 0; i < listPatients.Count; i++)
                    {
                        if (residence == listPatients[i].Residence && listPatients[i].Situacion == "Infected")
                        {
                            count++;
                            Console.Clear();
                            Console.WriteLine("*****************************************");
                            Console.WriteLine("*            Patient Info               *");
                            Console.WriteLine("*****************************************");
                            Console.WriteLine(listPatients[i].ToString());
                            Console.WriteLine("\n***************************************");
                        }
                        else if (count == 0 && residence == listPatients[i].Residence && listPatients[i].Situacion != "Infected")
                        {
                            Console.WriteLine("\nThere are patients with that location, but there are not infected!");
                        }
                    }
                    Console.ReadKey();
                    break;

                case ConsoleKey.D3:
                    Console.WriteLine("Infected:\n");

                    listPatients = PatientBR.ShowPatients();

                    gender = PersonFE.InsertGender();

                    if (listPatients.Count == 0)
                    {
                        Console.WriteLine("\nThere are not patients on the list with that gender!");
                        Console.ReadKey();
                        break;
                    }

                    for (int i = 0; i < listPatients.Count; i++)
                    {
                        if (gender == listPatients[i].Gender && listPatients[i].Situacion == "Infected")
                        {
                            count++;
                            Console.Clear();
                            Console.WriteLine("*****************************************");
                            Console.WriteLine("*            Patient Info               *");
                            Console.WriteLine("*****************************************");
                            Console.WriteLine(listPatients[i].ToString());
                            Console.WriteLine("\n***************************************");
                        }
                        else if (count == 0 && gender == listPatients[i].Gender && listPatients[i].Situacion != "Infected")
                        {
                            Console.WriteLine("\nThere are patients with that gender, but there are not infected!");
                        }
                    }
                    Console.ReadKey();
                    break;

                case ConsoleKey.D4:
                    Console.WriteLine("Infected:\n");

                    listPatients = PatientBR.ShowPatients();

                    Console.WriteLine("Insert age of person that you want so search.\n");
                    age = int.Parse(Console.ReadLine());

                    if (listPatients.Count == 0)
                    {
                        Console.WriteLine("There are not patients on the list with that age!");
                        Console.ReadKey();
                        break;
                    }

                    for (int i = 0; i < listPatients.Count; i++)
                    {
                        if (age == listPatients[i].Age && listPatients[i].Situacion == "Infected")
                        {
                            count++;
                            Console.Clear();
                            Console.WriteLine("*****************************************");
                            Console.WriteLine("*            Patient Info               *");
                            Console.WriteLine("*****************************************");
                            Console.WriteLine(listPatients[i].ToString());
                            Console.WriteLine("\n***************************************");
                        }
                        else if (count == 0 && age == listPatients[i].Age && listPatients[i].Situacion != "Infected")
                        {
                            Console.WriteLine("\nThere are patients with that age, but there are not infected!");
                        }
                    }
                    Console.ReadKey();
                    break;

                default:
                    break;
            }

        }

        public static void MenuSuspected(PatientBO pt, List<PatientBO> listPatients)
        {
            ConsoleKeyInfo number;
            string residence;
            string gender;
            int age;
            int count = 0;

            Console.Clear();

            Console.WriteLine("\t*******************************");
            Console.WriteLine("\t*       Insert an option      *");
            Console.WriteLine("\t*******************************");
            Console.WriteLine("\t*   [1]  List All             *");
            Console.WriteLine("\t*   [2]  List by Residence    *");
            Console.WriteLine("\t*   [3]  List by Gender       *");
            Console.WriteLine("\t*   [4]  List by Age          *");
            Console.WriteLine("\t*******************************");

            number = Console.ReadKey();

            Console.Clear();

            switch (number.Key)
            {
                case ConsoleKey.D1:
                    listPatients = PatientBR.ShowPatients();

                    for (int i = 0; i < listPatients.Count; i++)
                    {
                        if (listPatients[i].Situacion == "Suspected")
                        {
                            Console.WriteLine(listPatients[i].ToString());
                        }
                    }
                    Console.ReadKey();
                    break;

                case ConsoleKey.D2:
                    Console.WriteLine("Suspected:");

                    listPatients = PatientBR.ShowPatients();

                    residence = PersonFE.InsertResidence();

                    if (listPatients.Count == 0)
                    {
                        Console.WriteLine("There are not patients on the list with that residence!");
                        Console.ReadKey();
                        break;
                    }

                    for (int i = 0; i < listPatients.Count; i++)
                    {
                        if (residence == listPatients[i].Residence && listPatients[i].Situacion == "Suspected")
                        {
                            count++;
                            Console.Clear();
                            Console.WriteLine("*****************************************");
                            Console.WriteLine("*            Patient Info               *");
                            Console.WriteLine("*****************************************");
                            Console.WriteLine(listPatients[i].ToString());
                            Console.WriteLine("\n***************************************");
                        }
                        else if (count == 0 && residence == listPatients[i].Residence && listPatients[i].Situacion != "Suspected")
                        {
                            Console.WriteLine("\nThere are patients with that location, but there are not suspected!");
                        }
                    }
                    Console.ReadKey();
                    break;

                case ConsoleKey.D3:
                    Console.WriteLine("Suspected:\n");

                    listPatients = PatientBR.ShowPatients();

                    gender = PersonFE.InsertGender();

                    if (listPatients.Count == 0)
                    {
                        Console.WriteLine("\nThere are not patients on the list with that gender!");
                        Console.ReadKey();
                        break;
                    }

                    for (int i = 0; i < listPatients.Count; i++)
                    {
                        if (gender == listPatients[i].Gender && listPatients[i].Situacion == "Suspected")
                        {
                            count++;
                            Console.Clear();
                            Console.WriteLine("*****************************************");
                            Console.WriteLine("*            Patient Info               *");
                            Console.WriteLine("*****************************************");
                            Console.WriteLine(listPatients[i].ToString());
                            Console.WriteLine("\n***************************************");
                        }
                        else if (count == 0 && gender == listPatients[i].Gender && listPatients[i].Situacion != "Suspected")
                        {
                            Console.WriteLine("\nThere are patients with that gender, but there are not suspected!");
                        }
                    }
                    Console.ReadKey();
                    break;

                case ConsoleKey.D4:
                    Console.WriteLine("Suspected:\n");

                    listPatients = PatientBR.ShowPatients();

                    Console.WriteLine("Insert age of person that you want so search.\n");
                    age = int.Parse(Console.ReadLine());

                    if (listPatients.Count == 0)
                    {
                        Console.WriteLine("There are not patients on the list with that age!");
                        Console.ReadKey();
                        break;
                    }

                    for (int i = 0; i < listPatients.Count; i++)
                    {
                        if (age == listPatients[i].Age && listPatients[i].Situacion == "Suspected")
                        {
                            count++;
                            Console.Clear();
                            Console.WriteLine("*****************************************");
                            Console.WriteLine("*            Patient Info               *");
                            Console.WriteLine("*****************************************");
                            Console.WriteLine(listPatients[i].ToString());
                            Console.WriteLine("\n***************************************");
                        }
                        else if (count == 0 && age == listPatients[i].Age && listPatients[i].Situacion != "Suspected")
                        {
                            Console.WriteLine("\nThere are patients with that age, but there are not infected!");
                        }
                    }
                    Console.ReadKey();
                    break;

                default:
                    break;
            }
        }

        public static void MenuCured(PatientBO pt, List<PatientBO> listPatients)
        {
            ConsoleKeyInfo number;
            string residence;
            string gender;
            int age;
            int count = 0;

            Console.Clear();

            Console.WriteLine("\t*******************************");
            Console.WriteLine("\t*       Insert an option      *");
            Console.WriteLine("\t*******************************");
            Console.WriteLine("\t*   [1]  List All             *");
            Console.WriteLine("\t*   [2]  List by Residence    *");
            Console.WriteLine("\t*   [3]  List by Gender       *");
            Console.WriteLine("\t*   [4]  List by Age          *");
            Console.WriteLine("\t*******************************");

            number = Console.ReadKey();

            Console.Clear();

            switch (number.Key)
            {
                case ConsoleKey.D1:
                    listPatients = PatientBR.ShowPatients();

                    for (int i = 0; i < listPatients.Count; i++)
                    {
                        if (listPatients[i].Situacion == "Cured")
                        {
                            Console.WriteLine(listPatients[i].ToString());
                        }
                    }
                    Console.ReadKey();
                    break;

                case ConsoleKey.D2:
                    Console.WriteLine("Cured:");

                    listPatients = PatientBR.ShowPatients();

                    residence = PersonFE.InsertResidence();

                    if (listPatients.Count == 0)
                    {
                        Console.WriteLine("There are not patients on the list with that residence!");
                        Console.ReadKey();
                        break;
                    }

                    for (int i = 0; i < listPatients.Count; i++)
                    {
                        if (residence == listPatients[i].Residence && listPatients[i].Situacion == "Cured")
                        {
                            count++;
                            Console.Clear();
                            Console.WriteLine("*****************************************");
                            Console.WriteLine("*            Patient Info               *");
                            Console.WriteLine("*****************************************");
                            Console.WriteLine(listPatients[i].ToString());
                            Console.WriteLine("\n***************************************");
                        }
                        else if (count == 0 && residence == listPatients[i].Residence && listPatients[i].Situacion != "Cured")
                        {
                            Console.WriteLine("\nThere are patients with that location, but there are not cured!");
                        }
                    }
                    Console.ReadKey();
                    break;

                case ConsoleKey.D3:
                    Console.WriteLine("Cured:\n");

                    listPatients = PatientBR.ShowPatients();

                    gender = PersonFE.InsertGender();

                    if (listPatients.Count == 0)
                    {
                        Console.WriteLine("\nThere are not patients on the list with that gender!");
                        Console.ReadKey();
                        break;
                    }

                    for (int i = 0; i < listPatients.Count; i++)
                    {
                        if (gender == listPatients[i].Gender && listPatients[i].Situacion == "Cured")
                        {
                            count++;
                            Console.Clear();
                            Console.WriteLine("*****************************************");
                            Console.WriteLine("*            Patient Info               *");
                            Console.WriteLine("*****************************************");
                            Console.WriteLine(listPatients[i].ToString());
                            Console.WriteLine("\n***************************************");
                        }
                        else if (count == 0 && gender == listPatients[i].Gender && listPatients[i].Situacion != "Cured")
                        {
                            Console.WriteLine("\nThere are patients with that gender, but there are not cured!");
                        }
                    }
                    Console.ReadKey();
                    break;

                case ConsoleKey.D4:
                    Console.WriteLine("Cured:\n");

                    listPatients = PatientBR.ShowPatients();

                    Console.WriteLine("Insert age of person that you want so search.\n");
                    age = int.Parse(Console.ReadLine());

                    if (listPatients.Count == 0)
                    {
                        Console.WriteLine("There are not patients on the list with that age!");
                        Console.ReadKey();
                        break;
                    }

                    for (int i = 0; i < listPatients.Count; i++)
                    {
                        if (age == listPatients[i].Age && listPatients[i].Situacion == "Cured")
                        {
                            count++;
                            Console.Clear();
                            Console.WriteLine("*****************************************");
                            Console.WriteLine("*            Patient Info               *");
                            Console.WriteLine("*****************************************");
                            Console.WriteLine(listPatients[i].ToString());
                            Console.WriteLine("\n***************************************");
                        }
                        else if (count == 0 && age == listPatients[i].Age && listPatients[i].Situacion != "Cured")
                        {
                            Console.WriteLine("\nThere are patients with that age, but there are not cured!");
                        }
                    }
                    Console.ReadKey();
                    break;

                default:
                    break;
            }
        }

        public static void MenuDead(PatientBO pt, List<PatientBO> listPatients)
        {
            ConsoleKeyInfo number;
            string residence;
            string gender;
            int age;
            int count = 0;

            Console.Clear();

            Console.WriteLine("\t*******************************");
            Console.WriteLine("\t*       Insert an option      *");
            Console.WriteLine("\t*******************************");
            Console.WriteLine("\t*   [1]  List All             *");
            Console.WriteLine("\t*   [2]  List by Residence    *");
            Console.WriteLine("\t*   [3]  List by Gender       *");
            Console.WriteLine("\t*   [4]  List by Age          *");
            Console.WriteLine("\t*******************************");

            number = Console.ReadKey();

            Console.Clear();

            switch (number.Key)
            {
                case ConsoleKey.D1:
                    listPatients = PatientBR.ShowPatients();

                    for (int i = 0; i < listPatients.Count; i++)
                    {
                        if (listPatients[i].Situacion == "Dead")
                        {
                            Console.WriteLine(listPatients[i].ToString());
                        }
                    }
                    Console.ReadKey();
                    break;

                case ConsoleKey.D2:
                    Console.WriteLine("Dead:");

                    listPatients = PatientBR.ShowPatients();

                    residence = PersonFE.InsertResidence();

                    if (listPatients.Count == 0)
                    {
                        Console.WriteLine("There are not patients on the list with that dead!");
                        Console.ReadKey();
                        break;
                    }

                    for (int i = 0; i < listPatients.Count; i++)
                    {
                        if (residence == listPatients[i].Residence && listPatients[i].Situacion == "Dead")
                        {
                            count++;
                            Console.Clear();
                            Console.WriteLine("*****************************************");
                            Console.WriteLine("*            Patient Info               *");
                            Console.WriteLine("*****************************************");
                            Console.WriteLine(listPatients[i].ToString());
                            Console.WriteLine("\n***************************************");
                        }
                        else if (count == 0 && residence == listPatients[i].Residence && listPatients[i].Situacion != "Dead")
                        {
                            Console.WriteLine("\nThere are patients with that location, but there are not dead!");
                        }
                    }
                    Console.ReadKey();
                    break;

                case ConsoleKey.D3:
                    Console.WriteLine("Dead:\n");

                    listPatients = PatientBR.ShowPatients();

                    gender = PersonFE.InsertGender();

                    if (listPatients.Count == 0)
                    {
                        Console.WriteLine("\nThere are not patients on the list with that gender!");
                        Console.ReadKey();
                        break;
                    }

                    for (int i = 0; i < listPatients.Count; i++)
                    {
                        if (gender == listPatients[i].Gender && listPatients[i].Situacion == "Dead")
                        {
                            count++;
                            Console.Clear();
                            Console.WriteLine("*****************************************");
                            Console.WriteLine("*            Patient Info               *");
                            Console.WriteLine("*****************************************");
                            Console.WriteLine(listPatients[i].ToString());
                            Console.WriteLine("\n***************************************");
                        }
                        else if (count == 0 && gender == listPatients[i].Gender && listPatients[i].Situacion != "Dead")
                        {
                            Console.WriteLine("\nThere are patients with that gender, but there are not dead!");
                        }
                    }
                    Console.ReadKey();
                    break;

                case ConsoleKey.D4:
                    Console.WriteLine("Dead:\n");

                    listPatients = PatientBR.ShowPatients();

                    Console.WriteLine("Insert age of person that you want so search.\n");
                    age = int.Parse(Console.ReadLine());

                    if (listPatients.Count == 0)
                    {
                        Console.WriteLine("There are not patients on the list with that age!");
                        Console.ReadKey();
                        break;
                    }

                    for (int i = 0; i < listPatients.Count; i++)
                    {
                        if (age == listPatients[i].Age && listPatients[i].Situacion == "Dead")
                        {
                            count++;
                            Console.Clear();
                            Console.WriteLine("*****************************************");
                            Console.WriteLine("*            Patient Info               *");
                            Console.WriteLine("*****************************************");
                            Console.WriteLine(listPatients[i].ToString());
                            Console.WriteLine("\n***************************************");
                        }
                        else if (count == 0 && age == listPatients[i].Age && listPatients[i].Situacion != "Dead")
                        {
                            Console.WriteLine("\nThere are patients with that age, but there are not dead!");
                        }
                    }
                    Console.ReadKey();
                    break;

                default:
                    break;
            }
        }

        #endregion

        #endregion

        #region MENU_DOCTOR
        public static void MenuDoctor(DoctorBO d, List<DoctorBO> listDoctor)
        {
            ConsoleKeyInfo number;
            int option = 0;
            bool aux;
            int code = 0;

            do
            {
                Console.Clear();

                Console.WriteLine("\t***********************************");
                Console.WriteLine("\t*         Insert an option        *");
                Console.WriteLine("\t***********************************");
                Console.WriteLine("\t*   [1]  Insert Doctor            *");
                Console.WriteLine("\t*   [2]  List Doctors             *");
                Console.WriteLine("\t*   [3]  Edit Doctor              *");
                Console.WriteLine("\t*   [4]  Search Doctor Register   *");
                Console.WriteLine("\t***********************************");

                number = Console.ReadKey();

                Console.Clear();

                switch (number.Key)
                {
                    case ConsoleKey.D1:
                        Console.WriteLine("How many doctors do you want to insert?");
                        option = int.Parse(Console.ReadLine());

                        for (int i = 0; i < option; i++)
                        {
                            Console.WriteLine("\nPatient {0}:\n", i + 1);
                            d = DoctorFE.DoctorData(d);
                            aux = DoctorBR.InsertDoctor(d);

                            if (aux == true)
                            {
                                //listar dados
                                Console.WriteLine("\nSucessfully Inserted!\n");
                            }
                            else
                            {
                                Console.WriteLine("\nUnsucessfully Inserted!\n");
                            }
                        }
                        break;

                    case ConsoleKey.D2:
                        MenuList(d, listDoctor);
                        break;

                    case ConsoleKey.D3:
                        MenuEdit(d, listDoctor);
                        break;

                    case ConsoleKey.D4:
                        Console.WriteLine("Insert first four numbers from doctor code.\n");
                        code = int.Parse(Console.ReadLine());

                        listDoctor = DoctorBR.ShowDoctor();
                        if (listDoctor.Count == 0)
                        {
                            Console.WriteLine("There are not doctors on the list!");
                            Console.ReadKey();
                            break;
                        }

                        for (int i = 0; i < listDoctor.Count; i++)
                        {
                            if (code == listDoctor[i].CodeDoctor)
                            {
                                Console.Clear();
                                Console.WriteLine("*****************************************");
                                Console.WriteLine("*            Patient Info               *");
                                Console.WriteLine("*****************************************");
                                Console.WriteLine(listDoctor[i].ToString());
                                Console.WriteLine("\n***************************************");
                            }
                            else
                            {
                                Console.WriteLine("Invalid Code!");
                            }
                        }
                        Console.ReadKey();
                        break;
                    default:
                        break;
                }
            } while (number.Key != ConsoleKey.D0);

        }

        #region MENU_EDIT
        public static void MenuEdit(DoctorBO d, List<DoctorBO> listDoctor)
        {
            ConsoleKeyInfo number;
            int code;

            Console.Clear();

            Console.WriteLine("\t*******************************");
            Console.WriteLine("\t*       Insert an option      *");
            Console.WriteLine("\t*******************************");
            Console.WriteLine("\t*   [1]  Edit Residence       *");
            Console.WriteLine("\t*   [2]  Edit Specialty       *");
            Console.WriteLine("\t*   [3]  Edit Gender          *");
            Console.WriteLine("\t*******************************");

            number = Console.ReadKey();

            Console.Clear();

            listDoctor = DoctorBR.ShowDoctor();

            switch (number.Key)
            {
                case ConsoleKey.D1:
                    Console.WriteLine("Insert first four numbers from doctor code that you want to change.\n");
                    code = int.Parse(Console.ReadLine());

                    for (int i = 0; i < listDoctor.Count; i++)
                    {
                        if (code == listDoctor[i].CodePerson)
                        {
                            if (PersonBR.UpdatePerson(i, PersonFE.AssignResidence(listDoctor[i])))
                            {
                                Console.WriteLine("Update Successful!");
                            }
                            else
                            {
                                Console.WriteLine("Update Unsuccessful!");
                            }
                            break;
                        }
                    }
                    Console.ReadKey();
                    break;

                case ConsoleKey.D2:
                    Console.WriteLine("Insert first four numbers from doctor code that you want to change.\n");
                    code = int.Parse(Console.ReadLine());

                    for (int i = 0; i < listDoctor.Count; i++)
                    {
                        if (code == listDoctor[i].CodePerson)
                        {
                            if (PersonBR.UpdatePerson(i, DoctorFE.AssignWork(listDoctor[i])))
                            {
                                Console.WriteLine("Update Successful!");
                            }
                            else
                            {
                                Console.WriteLine("Update Unsuccessful!");
                            }
                            break;
                        }
                    }
                    Console.ReadKey();
                    break;

                case ConsoleKey.D3:
                    Console.WriteLine("Insert first four numbers from doctor code that you want to change.\n");
                    code = int.Parse(Console.ReadLine());

                    for (int i = 0; i < listDoctor.Count; i++)
                    {
                        if (code == listDoctor[i].CodePerson)
                        {
                            if (PersonBR.UpdatePerson(i, PersonFE.AssignGender(listDoctor[i])))
                            {
                                Console.WriteLine("Update Successful!");
                            }
                            else
                            {
                                Console.WriteLine("Update Unsuccessful!");
                            }
                            break;
                        }
                    }
                    Console.ReadKey();
                    break;
                default:
                    break;
            }

        }
        #endregion

        #region MENU_LIST
        public static void MenuList(DoctorBO d, List<DoctorBO> listDoctor)
        {
            ConsoleKeyInfo number;
            string residence;
            string gender;
            int age;
            string specialty;

            Console.Clear();

            Console.WriteLine("\t*******************************");
            Console.WriteLine("\t*       Insert an option      *");
            Console.WriteLine("\t*******************************");
            Console.WriteLine("\t*   [1]  List All             *");
            Console.WriteLine("\t*   [2]  List by Residence    *");
            Console.WriteLine("\t*   [3]  List by Gender       *");
            Console.WriteLine("\t*   [4]  List by Age          *");
            Console.WriteLine("\t*   [5]  List by Specialty    *");
            Console.WriteLine("\t*******************************");

            number = Console.ReadKey();

            Console.Clear();

            listDoctor = DoctorBR.ShowDoctor();

            switch (number.Key)
            {
                case ConsoleKey.D1:
                    Console.WriteLine("*****************************************");
                    Console.WriteLine("*            Doctor Info               *");

                    for (int i = 0; i < listDoctor.Count; i++)
                    {
                        Console.WriteLine("*****************************************");
                        Console.WriteLine(listDoctor[i].ToString());
                        Console.WriteLine("\n***************************************");
                    }
                    Console.ReadKey();
                    break;

                case ConsoleKey.D2:
                    residence = PersonFE.InsertResidence();

                    if (listDoctor.Count == 0)
                    {
                        Console.WriteLine("There are not doctors on the list with that residence!");
                        Console.ReadKey();
                        break;
                    }

                    for (int i = 0; i < listDoctor.Count; i++)
                    {
                        if (residence == listDoctor[i].Residence)
                        {
                            Console.Clear();
                            Console.WriteLine("*****************************************");
                            Console.WriteLine("*            Doctor Info               *");
                            Console.WriteLine("*****************************************");
                            Console.WriteLine(listDoctor[i].ToString());
                            Console.WriteLine("\n***************************************");
                        }
                        else
                        {
                            Console.WriteLine("\nThere are not doctores with that residence!");
                        }
                    }
                    Console.ReadKey();
                    break;

                case ConsoleKey.D3:
                    gender = PersonFE.InsertGender();

                    if (listDoctor.Count == 0)
                    {
                        Console.WriteLine("\nThere are not doctors on the list with that gender!");
                        Console.ReadKey();
                        break;
                    }

                    for (int i = 0; i < listDoctor.Count; i++)
                    {
                        if (gender == listDoctor[i].Gender)
                        {
                            Console.Clear();
                            Console.WriteLine("*****************************************");
                            Console.WriteLine("*            Doctor Info               *");
                            Console.WriteLine("*****************************************");
                            Console.WriteLine(listDoctor[i].ToString());
                            Console.WriteLine("\n***************************************");
                        }
                        else
                        {
                            Console.WriteLine("\nThere are not doctores with that gender!");
                        }
                    }
                    Console.ReadKey();
                    break;

                case ConsoleKey.D4:
                    Console.WriteLine("Insert age of doctor that you want so search.\n");
                    age = int.Parse(Console.ReadLine());

                    if (listDoctor.Count == 0)
                    {
                        Console.WriteLine("There are not doctors on the list with that age!");
                        Console.ReadKey();
                        break;
                    }

                    for (int i = 0; i < listDoctor.Count; i++)
                    {
                        if (age == listDoctor[i].Age)
                        {
                            Console.Clear();
                            Console.WriteLine("*****************************************");
                            Console.WriteLine("*            Doctor Info                *");
                            Console.WriteLine("*****************************************");
                            Console.WriteLine(listDoctor[i].ToString());
                            Console.WriteLine("\n***************************************");
                        }
                        else
                        {
                            Console.WriteLine("\nThere are not doctores with that age!");
                        }
                    }
                    Console.ReadKey();
                    break;

                case ConsoleKey.D5:
                    Console.WriteLine("Insert specialty of doctor that you want so search.\n");
                    specialty = Console.ReadLine();

                    if (listDoctor.Count == 0)
                    {
                        Console.WriteLine("There are not doctors on the list with that specialty!");
                        Console.ReadKey();
                        break;
                    }

                    for (int i = 0; i < listDoctor.Count; i++)
                    {
                        if (specialty == listDoctor[i].Work)
                        {
                            Console.Clear();
                            Console.WriteLine("*****************************************");
                            Console.WriteLine("*            Doctor Info                *");
                            Console.WriteLine("*****************************************");
                            Console.WriteLine(listDoctor[i].ToString());
                            Console.WriteLine("\n***************************************");
                        }
                        else
                        {
                            Console.WriteLine("\nThere are not doctores with that specialty!");
                        }
                    }
                    Console.ReadKey();
                    break;
                default:
                    break;
            }

        }
        #endregion

        #endregion

        public static void MenuDisease()
        {
            Console.Clear();

            Console.WriteLine(" [1]  Insert Symptoms ");
            Console.WriteLine(" [2]  List Symptoms   ");
        }

        #endregion

        //public static void MenuPerson(PersonBO p)
        //{
        //    int number = 0;
        //    int option = 0;
        //    bool aux;

        //    Console.Clear();

        //    Console.WriteLine(" [1]  Insert Person ");
        //    Console.WriteLine(" [2]  List Person   ");
        //    Console.WriteLine(" [3]  Remove Person ");
        //    Console.WriteLine(" [4]  Search Person ");

        //    number = int.Parse(Console.ReadLine());

        //    switch (number)
        //    {
        //        case 1:
        //            Console.WriteLine("How many people do you want to insert?");
        //            option = int.Parse(Console.ReadLine());

        //            for (int i = 0; i < option; i++)
        //            {
        //                Console.WriteLine("\nPerson {0}:\n", i+1);
        //                PersonFE.PersonData(p);
        //                aux = PersonBR.InsertPerson(p);

        //                if (aux == true)
        //                {
        //                    //listar dados
        //                    Console.WriteLine("\nSucessfully Inserted!\n");
        //                }
        //                else
        //                {
        //                    Console.WriteLine("\nUnsucessfully Inserted!\n");
        //                }
        //            }
        //            break;

        //        case 2:

        //            break;

        //        case 3:
        //            break;

        //        case 4:
        //            break;

        //        default:
        //            break;
        //    }

        //}
    }
}
