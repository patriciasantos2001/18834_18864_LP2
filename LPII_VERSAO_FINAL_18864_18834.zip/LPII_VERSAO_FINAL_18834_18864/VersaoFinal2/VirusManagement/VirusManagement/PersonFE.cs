﻿/*
 * VirusManagement (Front End): is the user interface and has the purpose of translating tasks and results to something the user can understand.
 *      - Class PersonFE: has the purpose of translating tasks and results that are related to the person to something the user can understand.
 *
 * Version: 1.0.0
 *
 * Author: 
 *       - Patrícia Santos (18864)
 *       - Fátima Neves (18834)
 *       
 * Email: 
 *       - a18864@alunos.ipca.pt
 *		 - a18834@alunos.ipca.pt
 *
 * IPCA | Ecola Superior de Tecnologia
 *
 * Engenharia de Sistemas Informáticos
 * 
 * Date: 22/05/2020
 *
 * Notes:	LP2 
 *			Trabalho Prático - Final Fase 
 */

using System;
using BusinessObjects;

namespace VirusManagement
{
    /// <summary>
    /// Class PersonFE
    /// </summary>
    public class PersonFE
    {
        #region METHODS

        /// <summary>
        /// Ask for person data
        /// </summary>
        /// <param name="p">Persons List</param>
        public static void PersonData(PersonBO p)
        {
            Boolean aux;
            DateTime b;

            //Ask Name
            Console.WriteLine("\n Insert Name:");
            p.Name = Console.ReadLine();

            //Ask Birthday
            do
            {
                //Insert birthday again
                Console.WriteLine("\n Insert Birthday:");
                aux = DateTime.TryParse(Console.ReadLine(), out b);

                //if aux == true, change DateTime b to p.Birthday
                if (aux == true)
                {
                    p.Birthday = b;
                    //break to end the cycle
                    break;
                }
                else
                {
                    Console.WriteLine("\n Invalid Date!");
                }

            } while (aux != true);

            //Insert Gender
            p = AssignGender(p);

            //Insert Residence
            p = AssignResidence(p);
        }

        /// <summary>
        /// Insert Gender automatically
        /// </summary>
        /// <param name="p">Persons List</param>
        /// <returns></returns>
        public static PersonBO AssignGender(PersonBO p)
        {
            ConsoleKeyInfo genderKey;

            do
            {
                Console.WriteLine("\n Insert Gender:");
                Console.WriteLine(" [ 1 ] Female\n [ 2 ] Male");
                genderKey = Console.ReadKey();

                switch (genderKey.Key)
                {
                    case ConsoleKey.D1:
                        p.GenderSituacion = Sex.FEMALE;
                        break;
                    case ConsoleKey.D2:
                        p.GenderSituacion = Sex.MALE;
                        break;
                    default:
                        Console.WriteLine("\n Invalid Value!");
                        break;
                }
            } while (genderKey.Key != ConsoleKey.D1 && genderKey.Key != ConsoleKey.D2);
            return p;
        }

        /// <summary>
        /// Insert Gender
        /// </summary>
        /// <returns></returns>
        public static string InsertGender()
        {
            string gender = "";
            ConsoleKeyInfo genderKey;

            do
            {
                Console.WriteLine("\n Insert Gender:");
                Console.WriteLine(" [ 1 ] Female\n [ 2 ] Male");
                genderKey = Console.ReadKey();

                switch (genderKey.Key)
                {
                    case ConsoleKey.D1:
                        gender = "Female";
                        break;
                    case ConsoleKey.D2:
                        gender = "Male";
                        break;
                    default:
                        Console.WriteLine("\n Invalid Value!\n");
                        break;
                }
            } while (genderKey.Key != ConsoleKey.D1 && genderKey.Key != ConsoleKey.D2);
            return gender;
        }

        /// <summary>
        /// Insert Residence automatically
        /// </summary>
        /// <param name="p">Persons List</param>
        /// <returns></returns>
        public static PersonBO AssignResidence(PersonBO p)
        {
            ConsoleKeyInfo residenceKey;

            do
            {
                Console.WriteLine("\nInsert residence of patient:");
                Console.WriteLine(" [ 1 ] Açores\n [ 2 ] Algarve\n [ 3 ] Lisboa\n [ 4 ] Madeira\n [ 5 ] Porto");
                residenceKey = Console.ReadKey();

                switch (residenceKey.Key)
                {
                    case ConsoleKey.D1:
                        p.ResidenceSituacion = Home.ACORES;
                        break;
                    case ConsoleKey.D2:
                        p.ResidenceSituacion = Home.ALGARVE;
                        break;
                    case ConsoleKey.D3:
                        p.ResidenceSituacion = Home.LISBOA;
                        break;
                    case ConsoleKey.D4:
                        p.ResidenceSituacion = Home.MADEIRA;
                        break;
                    case ConsoleKey.D5:
                        p.ResidenceSituacion = Home.PORTO;
                        break;
                    default:
                        Console.WriteLine("\n Invalid Value!");
                        break;
                }
            } while (residenceKey.Key != ConsoleKey.D1 && residenceKey.Key != ConsoleKey.D2 && residenceKey.Key != ConsoleKey.D3 && residenceKey.Key != ConsoleKey.D4 && residenceKey.Key != ConsoleKey.D5);
            return p;
        }

        /// <summary>
        /// Insert Residence
        /// </summary>
        /// <returns></returns>
        public static string InsertResidence()
        {
            string residence = "";
            ConsoleKeyInfo residenceKey;

            do
            {
                Console.WriteLine("\n\n Insert residence of patient");
                Console.WriteLine(" [ 1 ] Açores\n [ 2 ] Algarve\n [ 3 ] Lisboa\n [ 4 ] Madeira\n [ 5 ] Porto");
                residenceKey = Console.ReadKey();

                switch (residenceKey.Key)
                {
                    case ConsoleKey.D1:
                        residence = "Açores";
                        break;
                    case ConsoleKey.D2:
                        residence = "Algarve";
                        break;
                    case ConsoleKey.D3:
                        residence = "Lisboa";
                        break;
                    case ConsoleKey.D4:
                        residence = "Madeira";
                        break;
                    case ConsoleKey.D5:
                        residence = "Porto";
                        break;
                    default:
                        Console.WriteLine("\n Invalid Value!");
                        break;
                }
            } while (residenceKey.Key != ConsoleKey.D1 && residenceKey.Key != ConsoleKey.D2 && residenceKey.Key != ConsoleKey.D3 && residenceKey.Key != ConsoleKey.D4 && residenceKey.Key != ConsoleKey.D5);
            return residence;
        }
    }
    #endregion
}
