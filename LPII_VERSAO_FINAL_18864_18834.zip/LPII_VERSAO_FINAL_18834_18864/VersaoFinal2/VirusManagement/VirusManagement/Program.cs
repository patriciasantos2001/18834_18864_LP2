﻿/*
 * VirusManagement (Front End): is the user interface and has the purpose of translating tasks and results to something the user can understand.
 *      - Class Program
 *
 * Version: 1.0.0
 *
 * Author: 
 *       - Patrícia Santos (18864)
 *       - Fátima Neves (18834)
 *       
 * Email: 
 *       - a18864@alunos.ipca.pt
 *		 - a18834@alunos.ipca.pt
 *
 * IPCA | Ecola Superior de Tecnologia
 *
 * Engenharia de Sistemas Informáticos
 * 
 * Date: 22/05/2020
 *
 * Notes:	LP2 
 *			Trabalho Prático - Final Fase 
 */

using BusinessObjects;
using BusinessRules;
using System.Collections.Generic;

namespace VirusManagement
{
    /// <summary>
    /// Class Program
    /// </summary>
    class Program
    {
        /// <summary>
        /// Main
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            PersonBO p = new PersonBO();
            PatientBO pt = new PatientBO();
            DoctorBO d = new DoctorBO();
            List<PatientBO> listPatients = new List<PatientBO>();
            List<DoctorBO> listDoctor = new List<DoctorBO>();
            DoctorBR.LoadDoctorFile();
            PatientBR.LoadPatientFile();
            MenuFE.Menu(pt, listPatients, d, listDoctor);
            DoctorBR.SaveDoctorFile();
            PatientBR.SavePatientFile();
        }
    }
}
