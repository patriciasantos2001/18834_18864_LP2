﻿/*
 * VirusManagement (Front End): is the user interface and has the purpose of translating tasks and results to something the user can understand.
 *      - Class PatientFE: has the purpose of translating tasks and results, that are related to the patient to something the user can understand.
 *
 * Version: 1.0.0
 *
 * Author: 
 *       - Patrícia Santos (18864)
 *       - Fátima Neves (18834)
 *       
 * Email: 
 *       - a18864@alunos.ipca.pt
 *		 - a18834@alunos.ipca.pt
 *
 * IPCA | Ecola Superior de Tecnologia
 *
 * Engenharia de Sistemas Informáticos
 * 
 * Date: 22/05/2020
 *
 * Notes:	LP2 
 *			Trabalho Prático - Final Fase 
 */

using System;
using BusinessObjects;

namespace VirusManagement
{
    /// <summary>
    /// Class PatientFE
    /// </summary>
    class PatientFE
    {
        #region METHODS

        /// <summary>
        /// Ask for patient data
        /// </summary>
        /// <param name="pt">Patients List</param>
        /// <param name="code">Code</param>
        /// <returns></returns>
        public static PatientBO PatientData(PatientBO pt, int code)
        {
            Boolean aux;
            DateTime e;
            pt = new PatientBO();
            VirusBO v = new VirusBO();
            int codeP;

            pt.DoctorCode = code;

            PersonFE.PersonData(pt);

            do
            {
                Console.WriteLine("\n Insert patient code:");
                aux = int.TryParse(Console.ReadLine(), out codeP);

                //if aux == true
                if (aux)
                {
                    pt.CodePatient = code;
                    //break to end the cycle
                    break;
                }
                else
                {
                    Console.WriteLine("\n Invalid code!");
                }
            } while (!aux);

            //ask for 
            pt = AssignSituacion(pt);

            //Entry at Hospital
            do
            {
                Console.WriteLine("\n Entry at Hospital:");
                aux = DateTime.TryParse(Console.ReadLine(), out e);

                //if aux == true, change DateTime e to pt.EntryHospital
                if (aux == true)
                {
                    pt.EntryHospital = e;
                    //break to end the cycle
                    break;
                }
                else
                {
                    Console.WriteLine("\n Invalid Date!");
                }
            } while (aux != true);

            pt.Virus = VirusFE.VirusData(v);

            return pt;
        }

        /// <summary>
        /// Insert Situation automatically
        /// </summary>
        /// <param name="pt">Patients List</param>
        /// <returns></returns>
        public static PatientBO AssignSituacion(PatientBO pt)
        {
            ConsoleKeyInfo situacionKey;

            do
            {
                Console.WriteLine("\n Insert Situacion:");
                Console.WriteLine(" [ 1 ] Cured\n [ 2 ] Infected\n [ 3 ] Suspect\n [ 4 ] Dead");
                situacionKey = Console.ReadKey();

                switch (situacionKey.Key)
                {
                    case ConsoleKey.D1:
                        pt.StatusSituacion = Status.CURED;
                        break;
                    case ConsoleKey.D2:
                        pt.StatusSituacion = Status.INFECTED;
                        break;
                    case ConsoleKey.D3:
                        pt.StatusSituacion = Status.SUSPECTED;
                        break;
                    case ConsoleKey.D4:
                        pt.StatusSituacion = Status.DEAD;
                        break;
                    default:
                        Console.WriteLine("\n Invalid Value!");
                        break;
                }
            } while (situacionKey.Key != ConsoleKey.D1 && situacionKey.Key != ConsoleKey.D2 && situacionKey.Key != ConsoleKey.D3 && situacionKey.Key != ConsoleKey.D4);
            return pt;
        }
        #endregion
    }
}
