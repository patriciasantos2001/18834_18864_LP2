﻿/*
 * VirusManagement (Front End): is the user interface and has the purpose of translating tasks and results to something the user can understand.
 *      - Class DoctorFE: has the purpose of translating tasks and results, that are related to the doctor to something the user can understand.
 *
 * Version: 1.0.0
 *
 * Author: 
 *       - Patrícia Santos (18864)
 *       - Fátima Neves (18834)
 *       
 * Email: 
 *       - a18864@alunos.ipca.pt
 *		 - a18834@alunos.ipca.pt
 *
 * IPCA | Ecola Superior de Tecnologia
 *
 * Engenharia de Sistemas Informáticos
 * 
 * Date: 22/05/2020
 *
 * Notes:	LP2 
 *			Trabalho Prático - Final Fase 
 */

using System;
using BusinessObjects;

namespace VirusManagement
{
    /// <summary>
    /// Class DoctorFE
    /// </summary>
    public class DoctorFE
    {
        #region METHODS
        /// <summary>
        /// Ask for doctor data
        /// </summary>
        /// <param name="d">Doctors List</param>
        /// <returns></returns>
        public static DoctorBO DoctorData(DoctorBO d)
        {
            Boolean aux;
            int codeD;

            d = new DoctorBO();
            PersonFE.PersonData(d);

            do
            {
                Console.WriteLine("\n\n Insert doctor code:");
                aux = int.TryParse(Console.ReadLine(), out codeD);

                //if aux == true
                if (aux)
                {
                    d.CodeDoctor = codeD;
                    //break to end the cycle
                    break;
                }
                else
                {
                    Console.WriteLine("\n Invalid code!");
                }
            } while (!aux);

            d = AssignWork(d);

            return d;
        }

        /// <summary>
        /// Insert work speciality automatically
        /// </summary>
        /// <param name="d">Doctors List</param>
        /// <returns></returns>
        public static DoctorBO AssignWork(DoctorBO d)
        {
            ConsoleKeyInfo workKey;

            do
            {
                Console.WriteLine("\n Insert work Specialty:");
                Console.WriteLine(" [ 1 ] Neurology\n [ 2 ] Cardiology\n [ 3 ] Pediatrics\n [ 4 ] Surgery\n [ 5 ] Obstetrics\n [ 6 ] Orthopedics");
                workKey = Console.ReadKey();

                switch (workKey.Key)
                {
                    case ConsoleKey.D1:
                        d.SpecialtyWork = Speciality.NEUROLOGY;
                        break;
                    case ConsoleKey.D2:
                        d.SpecialtyWork = Speciality.CARDIOLOGY;
                        break;
                    case ConsoleKey.D3:
                        d.SpecialtyWork = Speciality.PEDIATRICS;
                        break;
                    case ConsoleKey.D4:
                        d.SpecialtyWork = Speciality.SURGERY;
                        break;
                    case ConsoleKey.D5:
                        d.SpecialtyWork = Speciality.OBSTETRICS;
                        break;
                    case ConsoleKey.D6:
                        d.SpecialtyWork = Speciality.ORTHOPEDICS;
                        break;
                    default:
                        Console.WriteLine("\n Invalid Value!\n");
                        break;
                }
            } while (workKey.Key != ConsoleKey.D1 && workKey.Key != ConsoleKey.D2 && workKey.Key != ConsoleKey.D3 && workKey.Key != ConsoleKey.D4 && workKey.Key != ConsoleKey.D5 && workKey.Key != ConsoleKey.D6 && workKey.Key != ConsoleKey.D7);
            return d;
        }

        /// <summary>
        /// Insert work speciality
        /// </summary>
        /// <returns></returns>
        public static string InsertDoctor()
        {
            string specialty = "";
            ConsoleKeyInfo workKey;

            do
            {
                Console.WriteLine("\n Insert work Specialty:");
                Console.WriteLine(" [ 1 ] Neurology\n [ 2 ] Cardiology\n [ 3 ] Pediatrics\n [ 4 ] Surgery\n [ 5 ] Obstetrics\n [ 6 ] Orthopedics");
                workKey = Console.ReadKey();

                switch (workKey.Key)
                {
                    case ConsoleKey.D1:
                        specialty = "Neurology";
                        break;
                    case ConsoleKey.D2:
                        specialty = "Cardiology";
                        break;
                    case ConsoleKey.D3:
                        specialty = "Pediatrics";
                        break;
                    case ConsoleKey.D4:
                        specialty = "Surgery";
                        break;
                    case ConsoleKey.D5:
                        specialty = "Obstetrics";
                        break;
                    case ConsoleKey.D6:
                        specialty = "Orthopedics";
                        break;
                    default:
                        Console.WriteLine("\n Invalid Value!");
                        break;
                }
            } while (workKey.Key != ConsoleKey.D1 && workKey.Key != ConsoleKey.D2 && workKey.Key != ConsoleKey.D3 && workKey.Key != ConsoleKey.D4 && workKey.Key != ConsoleKey.D5 && workKey.Key != ConsoleKey.D6 && workKey.Key != ConsoleKey.D7);
            return specialty;
        }
        #endregion
    }
}
