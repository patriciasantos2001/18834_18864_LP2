﻿/*
 * BusinessRules: has the purpose of insert rules, validations and data security.
 *      - Class PersonBR: has the purpose of insert rules, validations and data security, that is related to persons.
 *
 * Version: 1.0.0
 *
 * Author: 
 *       - Patrícia Santos (18864)
 *       - Fátima Neves (18834)
 *       
 * Email: 
 *       - a18864@alunos.ipca.pt
 *		 - a18834@alunos.ipca.pt
 *
 * IPCA | Ecola Superior de Tecnologia
 *
 * Engenharia de Sistemas Informáticos
 * 
 * Date: 22/05/2020
 *
 * Notes:	LP2 
 *			Trabalho Prático - Final Fase 
 */

using DataAccess;
using BusinessObjects;
using System.Collections.Generic;

namespace BusinessRules
{
    /// <summary>
    /// Class DoctorBR
    /// </summary>
    public class DoctorBR
    {
        /// <summary>
        /// Empty Constructor
        /// </summary>
        public DoctorBR()
        {
        }

        /// <summary>
        /// Show doctor
        /// </summary>
        /// <returns></returns>
        public static List<DoctorBO> ShowDoctor()
        {
            return Doctors.ShowDoctor();
        }

        /// <summary>
        /// Insertion of doctor
        /// </summary>
        /// <param name="d">Doctors List</param>
        /// <returns></returns>
        public static bool InsertDoctor(DoctorBO d)
        {
            return Doctors.AddDoctor(d);
        }

        /// <summary>
        /// Update of the doctor
        /// </summary>
        /// <param name="index">Index</param>
        /// <param name="d">Doctors List</param>
        /// <returns></returns>
        public static bool UpdateDoctor(int index, DoctorBO d)
        {
            return Doctors.UpdateDoctor(index, d);
        }

        ///<summary>
        ///Save the list of doctors in the binary files 
        /// </summary>
        public static void SaveDoctorFile()
        {
            Doctors.SaveFileDoctor();
        }

        ///<summary>
        ///Load the list of patients from the binary files 
        /// </summary>
        public static void LoadDoctorFile()
        {
            Doctors.LoadFileDoctor();
        }

        /// <summary>
        /// Verifies if the doctor exists
        /// </summary>
        /// <param name="code">Code</param>
        /// <returns></returns>
        public static bool ExistDoctor(int code)
        {
            return Doctors.ExistDoctor(code);
        }
    }
}
