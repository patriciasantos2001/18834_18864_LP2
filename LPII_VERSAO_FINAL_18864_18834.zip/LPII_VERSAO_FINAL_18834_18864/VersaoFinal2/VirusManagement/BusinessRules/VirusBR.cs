﻿/*
 * BusinessRules: has the purpose of insert rules, validations and data security.
 *      - Class VirusBR: has the purpose of insert rules, validations and data security, that is related to virus.
 *
 * Version: 1.0.0
 *
 * Author: 
 *       - Patrícia Santos (18864)
 *       - Fátima Neves (18834)
 *       
 * Email: 
 *       - a18864@alunos.ipca.pt
 *		 - a18834@alunos.ipca.pt
 *
 * IPCA | Ecola Superior de Tecnologia
 *
 * Engenharia de Sistemas Informáticos
 * 
 * Date: 22/05/2020
 *
 * Notes:	LP2 
 *			Trabalho Prático - Final Fase 
 */

using DataAccess;
using BusinessObjects;

namespace BusinessRules
{
    /// <summary>
    /// Class VirusBR
    /// </summary>
    public class VirusBR
    {
        /// <summary>
        /// Empty Constructor
        /// </summary>
        public VirusBR()
        {
        }
        /// <summary>
        /// Insertion of virus
        /// </summary>
        /// <param name="v">Virus List</param>
        /// <returns></returns>
        public static bool InsertPerson(VirusBO v)
        {
            return Virus.AddVirus(v);
        }
        /// <summary>
        /// Update of the virus
        /// </summary>
        /// <param name="index">Index</param>
        /// <param name="v">Virus List</param>
        /// <returns></returns>
        public static bool UpdatePerson(int index, VirusBO v)
        {
            return Virus.UpdateVirus(index, v);
        }
    }
}
