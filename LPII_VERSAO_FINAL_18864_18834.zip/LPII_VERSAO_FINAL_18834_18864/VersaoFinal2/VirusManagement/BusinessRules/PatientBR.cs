﻿/*
 * BusinessRules: has the purpose of insert rules, validations and data security.
 *      - Class PatientBR: has the purpose of insert rules, validations and data security, that is related to patients.
 *
 * Version: 1.0.0
 *
 * Author: 
 *       - Patrícia Santos (18864)
 *       - Fátima Neves (18834)
 *       
 * Email: 
 *       - a18864@alunos.ipca.pt
 *		 - a18834@alunos.ipca.pt
 *
 * IPCA | Ecola Superior de Tecnologia
 *
 * Engenharia de Sistemas Informáticos
 * 
 * Date: 22/05/2020
 *
 * Notes:	LP2 
 *			Trabalho Prático - Final Fase 
 */

using DataAccess;
using BusinessObjects;
using System.Collections.Generic;

namespace BusinessRules
{
    /// <summary>
    /// Class PatientBR
    /// </summary>
    public class PatientBR
    {
        /// <summary>
        /// Empty Constructor
        /// </summary>
        public PatientBR()
        {
        }

        /// <summary>
        /// Show patient
        /// </summary>
        /// <returns></returns>
        public static List<PatientBO> ShowPatients()
        {
            return Patients.ShowPatient();
        }

        /// <summary>
        /// Insertion of patient
        /// </summary>
        /// <param name="pt">Patients List</param>
        /// <returns></returns>
        public static bool InsertPatient(PatientBO pt)
        {
            return Patients.AddPatient(pt);
        }

        /// <summary>
        /// Update of the patient
        /// </summary>
        /// <param name="index">Index</param>
        /// <param name="pt">Patients List</param>
        /// <returns></returns>
        public static bool UpdatePatient(int index, PatientBO pt)
        {
            return Patients.UpdatePatient(index, pt);
        }

        ///<summary>
        ///Save the list of patients in the binary files 
        /// </summary>
        public static void SavePatientFile()
        {
            Patients.SaveFilePatients();
        }

        ///<summary>
        ///Load the list of patients from the binary files 
        /// </summary>
        public static void LoadPatientFile()
        {
            Patients.LoadFilePatients();
        }
    }
}
