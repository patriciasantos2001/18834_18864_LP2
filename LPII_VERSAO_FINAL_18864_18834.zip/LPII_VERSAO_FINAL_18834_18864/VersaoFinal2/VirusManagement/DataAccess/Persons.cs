﻿/*
 * DataAccess: has the purpose of manipulating data.
 *      - Class Persons: has the purpose of manipulating data, that is related to persons.
 *
 * Version: 1.0.0
 *
 * Author: 
 *       - Patrícia Santos (18864)
 *       - Fátima Neves (18834)
 *       
 * Email: 
 *       - a18864@alunos.ipca.pt
 *		 - a18834@alunos.ipca.pt
 *
 * IPCA | Ecola Superior de Tecnologia
 *
 * Engenharia de Sistemas Informáticos
 * 
 * Date: 22/05/2020
 *
 * Notes:	LP2 
 *			Trabalho Prático - Final Fase 
 */

using BusinessObjects;
using System.Collections.Generic;


namespace DataAccess
{
    /// <summary>
    /// Class Persons
    /// </summary>
    public class Persons
    {
        private static List<PersonBO> person;

        #region CONSTRUCTOR
        /// <summary>
        /// Static constructor that creates the person list
        /// </summary>
        static Persons()
        {
            person = new List<PersonBO>();
        }
        #endregion
        #region OVERRIDE

        #endregion

        #region METHODS

        /// <summary>
        /// Insert new person
        /// </summary>
        /// <param name="p">Persons List</param>
        /// <returns></returns>
        public static bool AddPerson(PersonBO p)
        {
            if (person.Contains(p)) return false;
            person.Add(p);
            return true;
        }
        /// <summary>
        /// Update person
        /// </summary>
        /// <param name="index">Index</param>
        /// <param name="p">Persons List</param>
        /// <returns></returns>
        public static bool UpdatePerson(int index, PersonBO p)
        {
            person.Insert(index, p);
            return true;
        }
        #endregion
    }
}
