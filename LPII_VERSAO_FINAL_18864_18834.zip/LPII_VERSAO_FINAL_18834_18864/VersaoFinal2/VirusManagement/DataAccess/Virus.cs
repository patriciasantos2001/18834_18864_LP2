﻿/*
 * DataAccess: has the purpose of manipulating data.
 *      - Class Virus: has the purpose of manipulating data, that is related to virus.
 *
 * Version: 1.0.0
 *
 * Author: 
 *       - Patrícia Santos (18864)
 *       - Fátima Neves (18834)
 *       
 * Email: 
 *       - a18864@alunos.ipca.pt
 *		 - a18834@alunos.ipca.pt
 *
 * IPCA | Ecola Superior de Tecnologia
 *
 * Engenharia de Sistemas Informáticos
 * 
 * Date: 22/05/2020
 *
 * Notes:	LP2 
 *			Trabalho Prático - Final Fase 
 */

using System.Collections.Generic;
using BusinessObjects;

namespace DataAccess
{
    /// <summary>
    /// Class Virus
    /// </summary>
    public class Virus
    {
        private static List<VirusBO> virus;

        #region CONSTRUCTOR
        /// <summary>
        /// Static constructor that creates the virus list
        /// </summary>
        static Virus()
        {
            virus = new List<VirusBO>();
        }
        #endregion
        #region OVERRIDE

        #endregion

        #region METHODS

        /// <summary>
        /// Insert virus data
        /// </summary>
        /// <param name="v">Virus List</param>
        /// <returns></returns>
        public static bool AddVirus(VirusBO v)
        {
            if (virus.Contains(v)) return false;
            virus.Add(v);
            return true;
        }

        /// <summary>
        /// Update virus data
        /// </summary>
        /// <param name="index">Index</param>
        /// <param name="v">Virus List</param>
        /// <returns></returns>
        public static bool UpdateVirus(int index, VirusBO v)
        {
            virus.Insert(index, v);
            return true;
        }
        #endregion
    }
}
