﻿/*
 * DataAccess: has the purpose of manipulating data.
 *      - Class Patients: has the purpose of manipulating data, that is related to patients.
 *
 * Version: 1.0.0
 *
 * Author: 
 *       - Patrícia Santos (18864)
 *       - Fátima Neves (18834)
 *       
 * Email: 
 *       - a18864@alunos.ipca.pt
 *		 - a18834@alunos.ipca.pt
 *
 * IPCA | Ecola Superior de Tecnologia
 *
 * Engenharia de Sistemas Informáticos
 * 
 * Date: 22/05/2020
 *
 * Notes:	LP2 
 *			Trabalho Prático - Final Fase 
 */

using BusinessObjects;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System;

namespace DataAccess
{
    /// <summary>
    /// Class Patients
    /// </summary>
    public class Patients
    {
        private static List<PatientBO> patient;
        private static string fileName;

        #region CONSTRUCTOR
        /// <summary>
        /// Static constructor that creates the patient list
        /// </summary>
        static Patients()
        {
            patient = new List<PatientBO>();
            fileName = @"Patients.bin";
        }
        #endregion
        #region OVERRIDE

        #endregion

        #region METHODS

        /// <summary>
        /// Show patient
        /// </summary>
        /// <returns></returns>
        public static List<PatientBO> ShowPatient()
        {
            // Creation of auxiliar list
            List<PatientBO> auxPatients = patient;
            return auxPatients;
        }

        /// <summary>
        /// Add patient
        /// </summary>
        /// <param name="pt">Patients List</param>
        /// <returns></returns>
        public static bool AddPatient(PatientBO pt)
        {
            if (patient.Contains(pt)) return false;
            patient.Add(pt);
            return true;
        }

        /// <summary>
        /// Update patient
        /// </summary>
        /// <param name="index">Index</param>
        /// <param name="pt">Patients List</param>
        /// <returns></returns>
        public static bool UpdatePatient(int index, PatientBO pt)
        {
            patient.Insert(index, pt);
            return true;
        }

        /// <summary>
        /// Save patients file
        /// </summary>
        public static void SaveFilePatients()
        {
            try
            {
                if (File.Exists(fileName))
                {
                    FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.ReadWrite);
                    BinaryFormatter bfw = new BinaryFormatter();
                    bfw.Serialize(fs, patient);
                    fs.Close();
                }
                else
                {
                    FileStream fs = new FileStream(fileName, FileMode.Create, FileAccess.ReadWrite);
                    BinaryFormatter bfw = new BinaryFormatter();
                    bfw.Serialize(fs, patient);
                    fs.Close();
                }
            }
            catch { throw new Exception("Error saving file..."); }
        }

        /// <summary>
        /// Load patients file
        /// </summary>
        public static void LoadFilePatients()
        {
            if (File.Exists(fileName))
            {
                Stream s = File.Open(fileName, FileMode.Open, FileAccess.Read);
                BinaryFormatter b = new BinaryFormatter();
                patient = (List<PatientBO>)b.Deserialize(s);
                s.Close();
            }
        }
        #endregion
    }
}
