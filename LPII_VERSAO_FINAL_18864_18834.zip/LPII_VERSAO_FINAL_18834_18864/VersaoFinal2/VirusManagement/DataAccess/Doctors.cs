﻿/*
 * DataAccess: has the purpose of manipulating data.
 *      - Class Doctors: has the purpose of manipulating data, that is related to doctors.
 *
 * Version: 1.0.0
 *
 * Author: 
 *       - Patrícia Santos (18864)
 *       - Fátima Neves (18834)
 *       
 * Email: 
 *       - a18864@alunos.ipca.pt
 *		 - a18834@alunos.ipca.pt
 *
 * IPCA | Ecola Superior de Tecnologia
 *
 * Engenharia de Sistemas Informáticos
 * 
 * Date: 22/05/2020
 *
 * Notes:	LP2 
 *			Trabalho Prático - Final Fase 
 */

using BusinessObjects;
using System.Collections.Generic;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System;

namespace DataAccess
{
    /// <summary>
    /// Class Doctors
    /// </summary>
    public class Doctors
    {
        private static List<DoctorBO> doctor;
        private static string fileName;

        #region CONSTRUCTOR
        /// <summary>
        /// Static constructor that creates the doctor list
        /// </summary>
        static Doctors()
        {
            doctor = new List<DoctorBO>();
            fileName = @"Doctors.bin";
        }
        #endregion
        /// <summary>
        /// Show doctor
        /// </summary>
        /// <returns></returns>
        public static List<DoctorBO> ShowDoctor()
        {
            // Creation of auxiliar list
            List<DoctorBO> auxDoctors = doctor;
            return auxDoctors;
        }

        #region METHODS

        /// <summary>
        /// Add doctor
        /// </summary>
        /// <param name="d">Doctors List</param>
        /// <returns></returns>
        public static bool AddDoctor(DoctorBO d)
        {
            if (doctor.Contains(d)) return false;
            doctor.Add(d);
            return true;
        }

        /// <summary>
        /// Update doctor
        /// </summary>
        /// <param name="index">Index</param>
        /// <param name="d">Doctors List</param>
        /// <returns></returns>
        public static bool UpdateDoctor(int index, DoctorBO d)
        {
            doctor.Insert(index, d);
            return true;
        }

        /// <summary>
        /// Save doctor file
        /// </summary>
        public static void SaveFileDoctor()
        {
            try
            {
                FileStream fs = new FileStream(fileName, FileMode.Append, FileAccess.Write);
                BinaryFormatter bfw = new BinaryFormatter();
                bfw.Serialize(fs, doctor);
                fs.Close();
            }
            catch { throw new Exception("Error saving file.."); }
        }

        /// <summary>
        /// Load doctor file
        /// </summary>
        public static void LoadFileDoctor()
        {
            if (File.Exists(fileName))
            {
                Stream s = File.Open(fileName, FileMode.Open, FileAccess.Read);
                if (s.Length > 0)
                {
                    BinaryFormatter b = new BinaryFormatter();
                    doctor = (List<DoctorBO>)b.Deserialize(s);
                }
                s.Close();
            }
        }

        /// <summary>
        /// Verifies if the doctor exists
        /// </summary>
        /// <param name="code">Code</param>
        /// <returns></returns>
        public static bool ExistDoctor(int code)
        {
            return doctor.Exists(d => d.CodeDoctor == code);
        }
        #endregion
    }
}
