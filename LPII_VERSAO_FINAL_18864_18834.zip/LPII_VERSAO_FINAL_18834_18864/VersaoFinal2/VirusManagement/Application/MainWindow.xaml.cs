﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Application
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DoctorMenu doctorMenu = new DoctorMenu();
        PatientsMenu patientsMenu = new PatientsMenu();
        CasesMenu casesMenu = new CasesMenu();
        public MainWindow()
        {
            //InitializeComponent();
        }

        private void Doctors_Click(object sender, RoutedEventArgs e)
        {
            doctorMenu.Show();
            Close();
        }

        private void Patients_Click(object sender, RoutedEventArgs e)
        {
            patientsMenu.Show();
            Close();
        }

        private void Virus_Click(object sender, RoutedEventArgs e)
        {
            casesMenu.Show();
            Close();
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            //App.Current.Shutdown();
        }
    }
}
