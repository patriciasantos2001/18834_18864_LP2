﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Application
{
    /// <summary>
    /// Interaction logic for CasesMenu.xaml
    /// </summary>
    public partial class CasesMenu : Window
    {
        public CasesMenu()
        {
            InitializeComponent();
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            //App.Current.Shutdown();
        }

        private void Suspected_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Infected_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Cured_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Dead_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Situation_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ListDoctors_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
