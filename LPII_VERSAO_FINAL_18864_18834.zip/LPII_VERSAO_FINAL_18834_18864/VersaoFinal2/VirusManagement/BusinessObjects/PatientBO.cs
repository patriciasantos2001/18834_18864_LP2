﻿/*
 * BusinessObjets: has the purpose of insert attributes, constructors and properties, which will be used in the other layers of the program.
 *      - Class PatientBO: has the purpose of insert attributes, constructors and properties, that are related to the patients, which will be used in the other layers of the program.
 *
 * Version: 1.0.0
 *
 * Author: 
 *       - Patrícia Santos (18864)
 *       - Fátima Neves (18834)
 *       
 * Email: 
 *       - a18864@alunos.ipca.pt
 *		 - a18834@alunos.ipca.pt
 *
 * IPCA | Ecola Superior de Tecnologia
 *
 * Engenharia de Sistemas Informáticos
 * 
 * Date: 22/05/2020
 *
 * Notes:	LP2 
 *			Trabalho Prático - Final Fase 
 */

using System;

namespace BusinessObjects
{
    /// <summary>
    /// Enum for the status
    /// </summary>
    public enum Status
    {
        CURED = 1,
        INFECTED = 2,
        SUSPECTED = 3,
        DEAD = 4
    }

    [Serializable]

    /// <summary>
    /// Class PatientBO
    /// </summary>
    public class PatientBO : PersonBO 
    {
        #region ATRIBUTES
        private int doctorCode;
        private string situacion;
        DateTime entryHospital;
        private int codePatient;
        private VirusBO virus;
        #endregion

        #region CONSTRUCTORS

        /// <summary>
        /// Empty Constructor
        /// </summary>
        public PatientBO()
        {

        }

        #endregion

        #region PROPERTIES
        /// <summary>
        /// Handle doctor code attribute
        /// </summary>
        public int DoctorCode
        {
            get => doctorCode;
            set => doctorCode = value;
        }

        /// <summary>
        /// Handle situacion attribute
        /// </summary>
        public string Situacion
        {
            get => situacion;
        }

        /// <summary>
        /// Handle data of entry in hospital attribute
        /// </summary>
        public DateTime EntryHospital
        {
            get => entryHospital;
            set => entryHospital = value;
        }

        /// <summary>
        /// Handle status situation attribute
        /// </summary>
        public Status StatusSituacion
        {
            set
            {
                if (value == Status.CURED)
                {
                    situacion = "Cured";
                }
                else if (value == Status.DEAD)
                {
                    situacion = "Dead";
                }
                else if (value == Status.INFECTED)
                {
                    situacion = "Infected";
                }
                else if (value == Status.SUSPECTED)
                {
                    situacion = "Suspected";
                }
            }
        }

        /// <summary>
        /// Handle code patient attribute
        /// </summary>
        public int CodePatient
        {
            get => codePatient;
            set => codePatient = value;
        }

        /// <summary>
        /// Handle virus attribute
        /// </summary>
        public VirusBO Virus
        {
            get => virus;
            set => virus = value;
        }
        #endregion

        #region OVERRIDE
        /// <summary>
        /// List persons
        /// </summary>
        public override string ToString()
        {
            return "\n Doctor code: " + DoctorCode + "\n Name: " + Name + "\n Age: " + Age + "\n Birthday: " + Birthday.ToShortDateString() + "\n Gender: " + Gender + "\n Residence: " + Residence + "\n Situacion: " + Situacion + "\n Entry Hospital: " + EntryHospital.ToShortDateString() + "\n Code: " + CodePatient;
        }
        #endregion
    }
}
