﻿/*
 * BusinessObjets: has the purpose of insert attributes, constructors and properties, which will be used in the other layers of the program.
 *      - Class VirusBO: has the purpose of insert attributes, constructors and properties, that are related to the virus, which will be used in the other layers of the program.
 *
 * Version: 1.0.0
 *
 * Author: 
 *       - Patrícia Santos (18864)
 *       - Fátima Neves (18834)
 *       
 * Email: 
 *       - a18864@alunos.ipca.pt
 *		 - a18834@alunos.ipca.pt
 *
 * IPCA | Ecola Superior de Tecnologia
 *
 * Engenharia de Sistemas Informáticos
 * 
 * Date: 22/05/2020
 *
 * Notes:	LP2 
 *			Trabalho Prático - Final Fase 
 */

namespace BusinessObjects
{
    /// <summary>
    /// Enum for the symptoms
    /// </summary>
    public enum Symptoms
    {
        FEVER = 1,
        MUSCLE_ACHES = 2,
        COUGH = 3,
        WEAKNESS = 4,
        RESPIRATORY_DIFFICULTIES = 5
    }

    /// <summary>
    /// Enum for the test results
    /// </summary>
    public enum TestResult
    {
        POSITIVE = 1,
        NEGATIVE = 2
    }

    /// <summary>
    /// Class VirusBO
    /// </summary>
    public class VirusBO
    {

        #region ATTRIBUTES
        string prognostic;
        string results;
        #endregion

        #region CONSTRUCTORS
        /// <summary>
        /// Empty Constructor
        /// </summary>
        public VirusBO()
        {

        }
        #endregion

        #region PROPERTIES

        /// <summary>
        /// Handle prognostic attribute
        /// </summary>
        public string Prognostic
        {
            get => prognostic;
        }

        /// <summary>
        /// Handle results attribute
        /// </summary>
        public string Results
        {
            get => results;
        }

        /// <summary>
        /// Handle prognostic attribute
        /// </summary>
        public Symptoms PrognosticVirus
        {
            set
            {
                if (value == Symptoms.FEVER)
                {
                    prognostic = "Fever";
                }
                else if (value == Symptoms.MUSCLE_ACHES)
                {
                    prognostic = "Muscle Aches";
                }
                else if (value == Symptoms.COUGH)
                {
                    prognostic = "Cough";
                }
                else if (value == Symptoms.RESPIRATORY_DIFFICULTIES)
                {
                    prognostic = "Respiratory Difficulties";
                }
                else if (value == Symptoms.WEAKNESS)
                {
                    prognostic = "Weakness";
                }
            }
        }

        /// <summary>
        /// Handle test result attribute
        /// </summary>
        public TestResult ResultTest
        {
            set
            {
                if (value == TestResult.NEGATIVE)
                {
                    results = "Negative";
                }
                else if (value == TestResult.POSITIVE)
                {
                    results = "Positive";
                }
            }
        }
        #endregion
    }
}

