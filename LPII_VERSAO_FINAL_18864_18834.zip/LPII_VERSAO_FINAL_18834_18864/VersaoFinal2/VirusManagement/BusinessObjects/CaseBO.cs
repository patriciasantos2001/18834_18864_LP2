﻿/*
 * BusinessObjets: has the purpose of insert attributes, constructors and properties, which will be used in the other layers of the program.
 *      - Class CaseBO: has the purpose of insert attributes, constructors and properties, that are related to the cases, which will be used in the other layers of the program.
 *
 * Version: 1.0.0
 *
 * Author: 
 *       - Patrícia Santos (18864)
 *       - Fátima Neves (18834)
 *       
 * Email: 
 *       - a18864@alunos.ipca.pt
 *		 - a18834@alunos.ipca.pt
 *
 * IPCA | Ecola Superior de Tecnologia
 *
 * Engenharia de Sistemas Informáticos
 * 
 * Date: 22/05/2020
 *
 * Notes:	LP2 
 *			Trabalho Prático - Final Fase 
 */

using System.Collections.Generic;

namespace BusinessObjects
{
    /// <summary>
    /// Class CaseBO
    /// </summary>
    public class CaseBO
    {
        #region ATTRIBUTES
        private static int countInfected;
        private static int countSuspected;
        private static int countDead;
        private static int countCured;
        #endregion

        #region CONSTRUCTORS
        /// <summary>
        /// Empty Constructor
        /// </summary>
        public CaseBO()
        {

        }
        #endregion

        #region PROPERTIES
        /// <summary>
        /// Handle infected counter attribute
        /// </summary>
        public int CountInfected
        {
            get => countInfected;
        }

        /// <summary>
        /// Handle suspected counter attribute
        /// </summary>
        public int CountSuspected
        {
            get => countSuspected;
        }

        /// <summary>
        /// Handle dead counter attribute
        /// </summary>
        public int CountDead
        {
            get => countDead;
        }

        /// <summary>
        /// Handle cured counter attribute
        /// </summary>
        public int CountCured
        {
            get => countCured;
        }
        #endregion

        /// <summary>
        /// Case counter by situation
        /// </summary>
        /// <param name="patients"></param>
        public static void CountCases(List<PatientBO> patients)
        {
            List<PatientBO> auxPatients;
            auxPatients = patients.FindAll(p => p.Situacion == "Cured");
            countCured = auxPatients.Count;
            auxPatients = patients.FindAll(p => p.Situacion == "Infected");
            countInfected = auxPatients.Count;
            auxPatients = patients.FindAll(p => p.Situacion == "Suspected");
            countSuspected = auxPatients.Count;
            auxPatients = patients.FindAll(p => p.Situacion == "Dead");
            countDead = auxPatients.Count;
        }
    }
}
