﻿/*
 * BusinessObjets: has the purpose of insert attributes, constructors and properties, which will be used in the other layers of the program.
 *      - Class DoctorBO: has the purpose of insert attributes, constructors and properties, that are related to the doctors, which will be used in the other layers of the program.
 *
 * Version: 1.0.0
 *
 * Author: 
 *       - Patrícia Santos (18864)
 *       - Fátima Neves (18834)
 *       
 * Email: 
 *       - a18864@alunos.ipca.pt
 *		 - a18834@alunos.ipca.pt
 *
 * IPCA | Ecola Superior de Tecnologia
 *
 * Engenharia de Sistemas Informáticos
 * 
 * Date: 22/05/2020
 *
 * Notes:	LP2 
 *			Trabalho Prático - Final Fase 
 */

using System;

namespace BusinessObjects
{
    /// <summary>
    /// Enum for doctors speciality
    /// </summary>
    public enum Speciality
    {
        NEUROLOGY = 1,
        CARDIOLOGY = 2,
        PEDIATRICS = 3,
        SURGERY = 4,
        OBSTETRICS = 5,
        ORTHOPEDICS = 6
    }

    /// <summary>
    /// Class DoctorBO
    /// </summary>
    [Serializable]
    public class DoctorBO : PersonBO
    {
        #region ATRIBUTES

        private string work;
        private int codeDoctor;

        #endregion

        #region CONSTRUCTORS

        /// <summary>
        /// Empty constructor
        /// </summary>
        public DoctorBO()
        {

        }

        #endregion

        #region PROPERTIES

        /// <summary>
        /// Handle work attribute
        /// </summary>
        public string Work
        {
            get => work;
        }

        /// <summary>
        /// Handle work speciality attribute
        /// </summary>
        public Speciality SpecialtyWork
        {
            set
            {
                if (value == Speciality.CARDIOLOGY)
                {
                    work = "Cardiology";
                }
                else if (value == Speciality.NEUROLOGY)
                {
                    work = "Neurology";
                }
                else if (value == Speciality.OBSTETRICS)
                {
                    work = "Obstetrics";
                }
                else if (value == Speciality.ORTHOPEDICS)
                {
                    work = "Orthopedics";
                }
                else if (value == Speciality.PEDIATRICS)
                {
                    work = "Pediatrics";
                }
                else if (value == Speciality.SURGERY)
                {
                    work = "Surgery";
                }
            }
        }

        /// <summary>
        /// Handle code doctor attribute
        /// </summary>
        public int CodeDoctor
        {
            get => codeDoctor;
            set => codeDoctor = value;
        }
        #endregion

        #region OVERRIDE
        /// <summary>
        /// List doctor
        /// </summary>
        public override string ToString()
        {
            return "\n Name: " + Name + "\n Age: " + Age + "\n Birthday: " + Birthday.ToShortDateString() + "\n Gender: " + Gender + "\n Residence: " +
                Residence + "\n Specialty: " + Work + "\n Code: " + CodeDoctor;
        }
        #endregion
    }
}
