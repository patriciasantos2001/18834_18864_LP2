﻿/*
 * BusinessObjets: has the purpose of insert attributes, constructors and properties, which will be used in the other layers of the program.
 *      - Class PersonBO: has the purpose of insert attributes, constructors and properties, that are related to the persons, which will be used in the other layers of the program.
 *
 * Version: 1.0.0
 *
 * Author: 
 *       - Patrícia Santos (18864)
 *       - Fátima Neves (18834)
 *       
 * Email: 
 *       - a18864@alunos.ipca.pt
 *		 - a18834@alunos.ipca.pt
 *
 * IPCA | Ecola Superior de Tecnologia
 *
 * Engenharia de Sistemas Informáticos
 * 
 * Date: 22/05/2020
 *
 * Notes:	LP2 
 *			Trabalho Prático - Final Fase 
 */

using System;

namespace BusinessObjects
{
    /// <summary>
    /// Enum for gender
    /// </summary>
    public enum Sex
    {
        FEMALE = 1,
        MALE = 2
    }

    /// <summary>
    /// Enum for residence
    /// </summary>
    public enum Home
    {
        ACORES = 1,
        ALGARVE = 2,
        LISBOA = 3,
        MADEIRA = 4,
        PORTO = 5
    }

    [Serializable]
    /// <summary>
    /// Class PersonBO
    /// </summary>
    public class PersonBO
    {
        #region ATTRIBUTES

        private string name;
        private DateTime birthday;
        private int age;
        private string gender;
        private string residence;

        #endregion

        #region CONSTRUCTORS

        /// <summary>
        /// Empty Constructor
        /// </summary>
        public PersonBO()
        {

        }
        #endregion

        #region PROPERTIES
        //Methods used to manipulate state attributes

        /// <summary>
        /// Handle name attribute
        /// </summary>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        /// <summary>
        /// Handle birthday attribute
        /// </summary>
        public DateTime Birthday
        {
            get { return birthday; }
            set
            {
                birthday = value;

                AssignAge();
            }
        }

        /// <summary>
        /// Handle Age attribute
        /// </summary>
        public int Age
        {
            get => age;
        }

        /// <summary>
        /// Handle Gender attribute
        /// </summary>
        public string Gender
        {
            get => gender;
        }

        /// <summary>
        /// Handle Residence Attribute
        /// </summary>
        public string Residence
        {
            get => residence;
        }

        /// <summary>
        /// Handle gender attribute
        /// </summary>
        public Sex GenderSituacion
        {
            set
            {
                if (value == Sex.FEMALE)
                {
                    gender = "Female";
                }
                else if (value == Sex.MALE)
                {
                    gender = "Male";
                }
            }
        }

        /// <summary>
        /// Handle residence attribute
        /// </summary>
        public Home ResidenceSituacion
        {
            set
            {
                if (value == Home.ACORES)
                {
                    residence = "Açores";
                }
                else if (value == Home.ALGARVE)
                {
                    residence = "Algarve";
                }
                else if (value == Home.LISBOA)
                {
                    residence = "Lisboa";
                }
                else if (value == Home.MADEIRA)
                {
                    residence = "Madeira";
                }
                else if (value == Home.PORTO)
                {
                    residence = "Porto";
                }
            }
        }

        #endregion

        #region METHODS
        /// <summary>
        /// Assign Age 
        /// </summary>
        private void AssignAge()
        {
            int currentYear;
            int birthdayYear;

            if (int.TryParse(DateTime.Today.Year.ToString(), out currentYear))
            {
                if (int.TryParse(birthday.Year.ToString(), out birthdayYear))
                {
                    if (birthday.Month == DateTime.Today.Month)
                    {
                        if (birthday.Day < DateTime.Today.Day)
                        {
                            currentYear -= 1;

                        }
                    }
                    else if (birthday.Month > birthday.Day)
                    {
                        currentYear -= 1;
                    }
                    age = currentYear - birthdayYear;
                }
            }
        }
        #endregion

        #region OVERRIDE
        /// <summary>
        /// List persons
        /// </summary>
        public override string ToString()
        {
            Console.WriteLine("\nPerson {0}:\n");
            return string.Format("\n Name: {0}\n Age: {1}\n Birthday: {2}\n Gender: {3}\n Residence: {4}\n",
                                 Name, Age, Birthday.ToShortDateString(), Residence);
        }
        #endregion
    }
}
